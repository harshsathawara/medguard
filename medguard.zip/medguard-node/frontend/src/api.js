// Thin fetch wrapper. The JWT is kept in localStorage and sent on every request.
const BASE = import.meta.env.VITE_API_URL || ''

export const tokenStore = {
  get() {
    try { return localStorage.getItem('mg_token') } catch { return null }
  },
  set(t) {
    try { t ? localStorage.setItem('mg_token', t) : localStorage.removeItem('mg_token') } catch { /* ignore */ }
  },
}

let onUnauthorized = () => {}
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn }

async function request(method, path, body) {
  const headers = { 'Content-Type': 'application/json' }
  const token = tokenStore.get()
  if (token) headers.Authorization = `Bearer ${token}`

  let res
  try {
    res = await fetch(`${BASE}/api${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new Error('Cannot reach the server. Check your connection and that the backend is running.')
  }

  if (res.status === 401 && !path.startsWith('/auth/')) {
    onUnauthorized()
    throw new Error('Your session has expired. Please log in again.')
  }

  const text = await res.text()
  const data = text ? JSON.parse(text) : null
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`)
  return data
}

export const api = {
  get: (p) => request('GET', p),
  post: (p, b) => request('POST', p, b ?? {}),
  put: (p, b) => request('PUT', p, b),
  del: (p) => request('DELETE', p),
}
