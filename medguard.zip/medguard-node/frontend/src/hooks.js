import { useCallback, useEffect, useRef, useState } from 'react'

/** Loads data on mount (and when deps change). Returns { data, error, loading, reload }. */
export function useLoad(fn, deps = []) {
  const [state, setState] = useState({ data: null, error: '', loading: true })
  const alive = useRef(true)
  const fnRef = useRef(fn)
  fnRef.current = fn

  const reload = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: '' }))
    try {
      const data = await fnRef.current()
      if (alive.current) setState({ data, error: '', loading: false })
    } catch (e) {
      if (alive.current) setState({ data: null, error: e.message, loading: false })
    }
  }, [])

  useEffect(() => {
    alive.current = true
    reload()
    return () => { alive.current = false }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return { ...state, reload }
}
