import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth.jsx'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Family from './pages/Family.jsx'
import Medicines from './pages/Medicines.jsx'
import MedicineForm from './pages/MedicineForm.jsx'
import Check from './pages/Check.jsx'
import Reports from './pages/Reports.jsx'
import Notifications from './pages/Notifications.jsx'

function Protected() {
  const { user, loading } = useAuth()
  if (loading) return <div className="center muted">Loading...</div>
  return user ? <Layout /> : <Navigate to="/login" replace />
}

export default function App() {
  const { user, loading } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={!loading && user ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<Protected />}>
        <Route index element={<Dashboard />} />
        <Route path="medicines" element={<Medicines />} />
        <Route path="medicines/new" element={<MedicineForm />} />
        <Route path="medicines/:id/edit" element={<MedicineForm />} />
        <Route path="family" element={<Family />} />
        <Route path="check" element={<Check />} />
        <Route path="reports" element={<Reports />} />
        <Route path="notifications" element={<Notifications />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
