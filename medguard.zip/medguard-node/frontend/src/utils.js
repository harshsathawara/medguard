const MONTHS = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12,
}

const pad = (n) => String(n).padStart(2, '0')

/** Medicine strips print expiry as a month, valid until the end of that month. */
function endOfMonth(year, month) {
  const y = year < 100 ? 2000 + year : year
  if (month < 1 || month > 12 || y < 2000 || y > 2100) return null
  const last = new Date(y, month, 0).getDate()
  return `${y}-${pad(month)}-${pad(last)}`
}

/**
 * Pulls a batch number and an expiry date out of OCR text from a medicine strip.
 * Best effort only: the user always gets to review and correct the result.
 */
export function parseStripText(raw) {
  const text = (raw || '').replace(/[|]/g, 'I').replace(/\s+/g, ' ')
  const out = { batchNumber: '', expiryDate: '' }

  const batch = text.match(/\b(?:B\.?\s?NO\.?|BN|BATCH\s?(?:NO\.?|NUMBER)?|LOT|B\/N)\s*[:.\-]?\s*([A-Z0-9][A-Z0-9\-\/]{2,})/i)
  if (batch) out.batchNumber = batch[1].toUpperCase()

  // "EXP 08/2027", "EXP. DATE: 08-27", "Expiry: AUG 2027", "EXP AUG.2027"
  const ctx = text.match(/(?:EXP(?:IRY)?\.?(?:\s?DATE)?|USE BEFORE)\s*[:.\-]?\s*([A-Za-z0-9\/\-. ]{4,14})/i)
  const scan = ctx ? ctx[1] : text
  let m = scan.match(/\b(0?[1-9]|1[0-2])\s*[\/\-.]\s*(20\d{2}|\d{2})\b/)
  if (m) {
    out.expiryDate = endOfMonth(parseInt(m[2], 10), parseInt(m[1], 10)) || ''
  } else {
    m = scan.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*[\s.\-\/]*(20\d{2}|\d{2})\b/i)
    if (m) out.expiryDate = endOfMonth(parseInt(m[2], 10), MONTHS[m[1].toLowerCase()]) || ''
  }
  return out
}

export function fmtDate(iso) {
  if (!iso) return '-'
  const [y, m, d] = iso.split('-').map(Number)
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
}

export function fmtTime24to12(hhmm) {
  const [h, m] = hhmm.split(':').map(Number)
  const d = new Date()
  d.setHours(h, m, 0, 0)
  return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
}

export function timeAgo(iso) {
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000))
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.round(s / 60)} min ago`
  if (s < 86400) return `${Math.round(s / 3600)} h ago`
  return `${Math.round(s / 86400)} d ago`
}
