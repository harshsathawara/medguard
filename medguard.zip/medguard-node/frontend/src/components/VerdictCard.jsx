const LABEL = {
  SAFE: 'No problems found',
  CAUTION: 'Check before using',
  DANGER: 'Do not use',
}

const ICON = { SAFE: '✓', CAUTION: '!', DANGER: '✕' }

/** Shows the result of a strip check. `v` is the VerificationResult from the API. */
export default function VerdictCard({ v, compact = false }) {
  if (!v) return null
  const auth = {
    VERIFIED: 'Confirmed by the official registry',
    NOT_FOUND: 'Not found in the official registry',
    UNAVAILABLE: 'Not verified against an official registry',
  }[v.authenticity]

  return (
    <div className={`verdict verdict-${v.verdict.toLowerCase()}`} role="status">
      <div className="verdict-head">
        <span className="verdict-icon" aria-hidden="true">{ICON[v.verdict]}</span>
        <strong>{LABEL[v.verdict]}</strong>
      </div>
      {!compact && (
        <ul className="verdict-list">
          {v.messages.map((m, i) => <li key={i}>{m}</li>)}
        </ul>
      )}
      <div className="verdict-meta">
        <span className={`chip chip-${v.expiry === 'OK' ? 'ok' : v.expiry === 'UNKNOWN' ? 'muted' : 'bad'}`}>
          Expiry: {v.expiry.replace('_', ' ').toLowerCase()}
        </span>
        <span className={`chip chip-${v.batch === 'CLEAN' ? 'ok' : v.batch === 'NOT_CHECKED' ? 'muted' : 'bad'}`}>
          Batch: {v.batch.replace('_', ' ').toLowerCase()}
        </span>
        <span className={`chip chip-${v.authenticity === 'VERIFIED' ? 'ok' : v.authenticity === 'NOT_FOUND' ? 'bad' : 'muted'}`}>
          {auth}
        </span>
      </div>
    </div>
  )
}
