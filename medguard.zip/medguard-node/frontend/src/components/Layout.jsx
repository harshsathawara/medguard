import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, Link } from 'react-router-dom'
import { api } from '../api.js'
import { useAuth } from '../auth.jsx'

const links = [
  { to: '/', label: 'Today', end: true, icon: '◉' },
  { to: '/medicines', label: 'Medicines', icon: '✚' },
  { to: '/family', label: 'Family', icon: '☺' },
  { to: '/check', label: 'Check', icon: '✓' },
  { to: '/reports', label: 'Reports', icon: '⚑' },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [unread, setUnread] = useState(0)

  useEffect(() => {
    api.get('/notifications')
      .then((list) => setUnread(list.filter((n) => !n.seen).length))
      .catch(() => {})
  }, [location.pathname])

  return (
    <div className="shell">
      <header className="topbar">
        <Link to="/" className="brand">
          <span className="logo">✚</span> MedGuard
        </Link>
        <nav className="nav desktop-nav" aria-label="Main">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => (isActive ? 'active' : '')}>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="topbar-right">
          <Link to="/notifications" className="bell" aria-label={`Notifications, ${unread} unread`}>
            🔔{unread > 0 && <span className="badge">{unread > 9 ? '9+' : unread}</span>}
          </Link>
          <span className="who">{user?.name}</span>
          <button className="btn ghost small" onClick={logout}>Log out</button>
        </div>
      </header>

      <main className="content">
        <Outlet />
      </main>

      <nav className="tabbar" aria-label="Main">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => (isActive ? 'active' : '')}>
            <span className="tab-icon">{l.icon}</span>
            {l.label}
          </NavLink>
        ))}
      </nav>
    </div>
  )
}
