import { useEffect, useRef, useState } from 'react'
import { parseStripText } from '../utils.js'

/**
 * Two ways to read a strip:
 *  1. Camera scan of the barcode / QR / DataMatrix  -> onCode(text)
 *  2. Photo of the printed text (batch + expiry), read with OCR in the browser -> onText({batchNumber, expiryDate})
 *
 * Browsers only allow camera access on https:// or http://localhost.
 */
export default function Scanner({ onCode, onText }) {
  const scannerRef = useRef(null)
  const [running, setRunning] = useState(false)
  const [busy, setBusy] = useState('')
  const [error, setError] = useState('')
  const [lastRead, setLastRead] = useState('')

  async function stopCamera() {
    const s = scannerRef.current
    scannerRef.current = null
    if (s) {
      try {
        if (s.isScanning) await s.stop()
        s.clear()
      } catch { /* already stopped */ }
    }
    setRunning(false)
  }

  useEffect(() => () => { stopCamera() }, [])

  async function startCamera() {
    setError('')
    setRunning(true)
    try {
      const { Html5Qrcode } = await import('html5-qrcode')
      const scanner = new Html5Qrcode('qr-reader')
      scannerRef.current = scanner
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 260, height: 180 } },
        (text) => {
          setLastRead(text)
          onCode?.(text)
          stopCamera()
        },
        () => { /* no code in this frame */ },
      )
    } catch (e) {
      scannerRef.current = null
      setRunning(false)
      setError('Could not open the camera. Allow camera access (needs https or localhost), or use "Read text from a photo".')
    }
  }

  async function readPhoto(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setError('')
    setBusy('Reading text... 0%')
    try {
      const { default: Tesseract } = await import('tesseract.js')
      const { data } = await Tesseract.recognize(file, 'eng', {
        logger: (m) => {
          if (m.status === 'recognizing text') setBusy(`Reading text... ${Math.round(m.progress * 100)}%`)
        },
      })
      const parsed = parseStripText(data.text)
      if (!parsed.batchNumber && !parsed.expiryDate) {
        setError('Could not find a batch number or expiry date in that photo. Try a closer, well-lit, flat photo, or type them in.')
      } else {
        onText?.(parsed)
      }
    } catch {
      setError('Text reading failed. Check your internet connection (the reader downloads language data) or type the details in.')
    } finally {
      setBusy('')
    }
  }

  return (
    <div className="scanner card soft">
      <div className="scanner-actions">
        {!running ? (
          <button type="button" className="btn" onClick={startCamera} disabled={!!busy}>
            Scan barcode / QR
          </button>
        ) : (
          <button type="button" className="btn ghost" onClick={stopCamera}>Stop camera</button>
        )}
        <label className={`btn ghost ${busy ? 'disabled' : ''}`}>
          Read text from a photo
          <input type="file" accept="image/*" capture="environment" hidden onChange={readPhoto} disabled={!!busy || running} />
        </label>
      </div>
      <div id="qr-reader" className="qr-reader" style={{ display: running ? 'block' : 'none' }} />
      {busy && <p className="muted">{busy}</p>}
      {lastRead && !running && <p className="muted small-text">Code read: <code>{lastRead.slice(0, 80)}</code></p>}
      {error && <p className="error">{error}</p>}
      <p className="muted small-text">
        Always check what was read. Photo reading is a best guess and can misread digits.
      </p>
    </div>
  )
}
