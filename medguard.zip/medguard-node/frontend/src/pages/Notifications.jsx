import { api } from '../api.js'
import { useLoad } from '../hooks.js'
import { timeAgo } from '../utils.js'

const TYPE = {
  DOSE_MISSED: 'Missed dose',
  REFILL: 'Refill',
  EXPIRY: 'Expiry',
}

export default function Notifications() {
  const { data, error, loading, reload } = useLoad(() => api.get('/notifications'))

  async function markAll() {
    try {
      await api.post('/notifications/seen-all')
      await reload()
    } catch { /* shown on next load */ }
  }

  const unread = data?.filter((n) => !n.seen).length || 0

  return (
    <div className="stack-lg">
      <div className="row between wrap">
        <h2>Notifications</h2>
        {unread > 0 && <button className="btn ghost small" onClick={markAll}>Mark all as read</button>}
      </div>
      {loading && !data && <p className="muted">Loading...</p>}
      {error && <p className="error">{error}</p>}
      {data?.length === 0 && <p className="muted">Nothing yet. Missed doses, refills and expiries show up here.</p>}
      <div className="stack">
        {data?.map((n) => (
          <div key={n.id} className={`card note ${n.seen ? '' : 'unread'}`}>
            <div className="row between">
              <span className="chip chip-muted">{TYPE[n.type] || n.type}</span>
              <span className="muted small-text">{timeAgo(n.createdAt)}</span>
            </div>
            <p>{n.message}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
