import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { useLoad } from '../hooks.js'

const empty = { name: '', relation: '', phone: '', language: '' }

export default function Family() {
  const { data, error, loading, reload } = useLoad(() => api.get('/members'))
  const [form, setForm] = useState(empty)
  const [editingId, setEditingId] = useState(null)
  const [formError, setFormError] = useState('')
  const [busy, setBusy] = useState(false)

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  async function save(e) {
    e.preventDefault()
    setFormError('')
    setBusy(true)
    try {
      if (editingId) await api.put(`/members/${editingId}`, form)
      else await api.post('/members', form)
      setForm(empty)
      setEditingId(null)
      await reload()
    } catch (err) {
      setFormError(err.message)
    } finally {
      setBusy(false)
    }
  }

  function edit(m) {
    setEditingId(m.id)
    setForm({ name: m.name, relation: m.relation || '', phone: m.phone || '', language: m.language || '' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  async function remove(m) {
    const extra = m.medicineCount ? ` This also deletes their ${m.medicineCount} medicine(s).` : ''
    if (!window.confirm(`Delete ${m.name}?${extra}`)) return
    try {
      await api.del(`/members/${m.id}`)
      await reload()
    } catch (err) {
      setFormError(err.message)
    }
  }

  return (
    <div className="stack-lg">
      <h2>Family</h2>
      <p className="muted">The people whose medicines you look after. You can add yourself too.</p>

      <form className="card stack" onSubmit={save}>
        <h3>{editingId ? 'Edit person' : 'Add a person'}</h3>
        <div className="grid2">
          <label>Name
            <input value={form.name} onChange={set('name')} required placeholder="e.g. Papa" />
          </label>
          <label>Relation
            <input value={form.relation} onChange={set('relation')} placeholder="Father, Mother, Self..." />
          </label>
          <label>Their phone <span className="hint">(for dose reminders)</span>
            <input value={form.phone} onChange={set('phone')} inputMode="tel" />
          </label>
          <label>Preferred language
            <input value={form.language} onChange={set('language')} placeholder="Hindi, Gujarati, English..." />
          </label>
        </div>
        {formError && <p className="error">{formError}</p>}
        <div className="row">
          <button className="btn" disabled={busy}>{editingId ? 'Save changes' : 'Add person'}</button>
          {editingId && <button type="button" className="btn ghost" onClick={() => { setEditingId(null); setForm(empty) }}>Cancel</button>}
        </div>
      </form>

      {loading && !data && <p className="muted">Loading...</p>}
      {error && <p className="error">{error}</p>}
      <div className="stack">
        {data?.map((m) => (
          <div key={m.id} className="card row between wrap">
            <div>
              <strong>{m.name}</strong> {m.relation && <span className="muted">({m.relation})</span>}
              <div className="muted small-text">
                {m.medicineCount} medicine(s){m.phone ? ` | ${m.phone}` : ''}{m.language ? ` | ${m.language}` : ''}
              </div>
            </div>
            <div className="row">
              <Link className="btn ghost small" to={`/medicines?memberId=${m.id}`}>Medicines</Link>
              <button className="btn ghost small" onClick={() => edit(m)}>Edit</button>
              <button className="btn danger small" onClick={() => remove(m)}>Delete</button>
            </div>
          </div>
        ))}
        {data && data.length === 0 && <p className="muted">No one added yet.</p>}
      </div>
    </div>
  )
}
