import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api } from '../api.js'
import { useLoad } from '../hooks.js'
import { timeAgo } from '../utils.js'

export default function Reports() {
  const [params] = useSearchParams()
  const { data, error, loading, reload } = useLoad(() => api.get('/reports'))
  const [form, setForm] = useState({
    medicineName: params.get('name') || '', batchNumber: params.get('batch') || '',
    manufacturer: '', pharmacy: '', reason: '',
  })
  const [formError, setFormError] = useState('')
  const [done, setDone] = useState(false)
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setFormError('')
    setDone(false)
    setBusy(true)
    try {
      await api.post('/reports', form)
      setForm({ medicineName: '', batchNumber: '', manufacturer: '', pharmacy: '', reason: '' })
      setDone(true)
      await reload()
    } catch (err) {
      setFormError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="stack-lg">
      <h2>Report a suspicious batch</h2>
      <p className="muted">
        If a pack looks wrong (misspelt label, odd colour, damaged seal, different from the usual one), tell others.
        A batch is flagged as suspicious once several different people report it.
        For a safety concern, also tell your pharmacist and your country's drug regulator.
      </p>

      <form className="card stack" onSubmit={submit}>
        <div className="grid2">
          <label>Medicine name
            <input value={form.medicineName} onChange={set('medicineName')} required />
          </label>
          <label>Batch number
            <input value={form.batchNumber} onChange={set('batchNumber')} required />
          </label>
          <label>Manufacturer <span className="hint">(optional)</span>
            <input value={form.manufacturer} onChange={set('manufacturer')} />
          </label>
          <label>Where you bought it <span className="hint">(optional)</span>
            <input value={form.pharmacy} onChange={set('pharmacy')} />
          </label>
        </div>
        <label>What looked wrong?
          <textarea rows="3" value={form.reason} onChange={set('reason')} />
        </label>
        {formError && <p className="error">{formError}</p>}
        {done && <p className="ok-text">Thank you. Your report was added.</p>}
        <button className="btn" disabled={busy}>Submit report</button>
      </form>

      <section className="stack">
        <h3>Your reports</h3>
        {loading && !data && <p className="muted">Loading...</p>}
        {error && <p className="error">{error}</p>}
        {data?.length === 0 && <p className="muted">You have not reported anything.</p>}
        {data?.map((r) => (
          <div key={r.id} className="card">
            <strong>{r.medicineName}</strong> <span className="muted">batch {r.batchNumber} | {timeAgo(r.createdAt)}</span>
            {r.reason && <p>{r.reason}</p>}
          </div>
        ))}
      </section>
    </div>
  )
}
