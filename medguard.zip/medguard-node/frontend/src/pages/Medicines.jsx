import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api.js'
import { useLoad } from '../hooks.js'
import VerdictCard from '../components/VerdictCard.jsx'
import { fmtDate, fmtTime24to12 } from '../utils.js'

export default function Medicines() {
  const [params, setParams] = useSearchParams()
  const memberId = params.get('memberId') || ''
  const members = useLoad(() => api.get('/members'))
  const meds = useLoad(() => api.get(`/medicines${memberId ? `?memberId=${memberId}` : ''}`), [memberId])
  const [refillFor, setRefillFor] = useState(null)
  const [qty, setQty] = useState(30)
  const [error, setError] = useState('')

  async function refill(m) {
    setError('')
    try {
      await api.post(`/medicines/${m.id}/refill`, { quantity: Number(qty) })
      setRefillFor(null)
      await meds.reload()
    } catch (e) {
      setError(e.message)
    }
  }

  async function remove(m) {
    if (!window.confirm(`Delete ${m.name} for ${m.memberName}? Its dose history is deleted too.`)) return
    setError('')
    try {
      await api.del(`/medicines/${m.id}`)
      await meds.reload()
    } catch (e) {
      setError(e.message)
    }
  }

  return (
    <div className="stack-lg">
      <div className="row between wrap">
        <h2>Medicines</h2>
        <Link to="/medicines/new" className="btn">+ Add medicine</Link>
      </div>

      {members.data?.length > 1 && (
        <label className="inline">Show for
          <select value={memberId} onChange={(e) => setParams(e.target.value ? { memberId: e.target.value } : {})}>
            <option value="">Everyone</option>
            {members.data.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
        </label>
      )}

      {error && <p className="error">{error}</p>}
      {meds.loading && !meds.data && <p className="muted">Loading...</p>}
      {meds.error && <p className="error">{meds.error}</p>}
      {meds.data && meds.data.length === 0 && (
        <div className="card soft">
          <p>No medicines yet. {members.data?.length === 0
            ? <>First <Link to="/family">add a family member</Link>, then add their medicines.</>
            : <>Tap <strong>Add medicine</strong> and scan the strip.</>}
          </p>
        </div>
      )}

      <div className="stack">
        {meds.data?.map((m) => {
          const scheduled = m.doseTimes.length > 0
          const low = scheduled && m.daysLeft <= m.refillLeadDays
          return (
            <article key={m.id} className={`card med ${m.active ? '' : 'inactive'}`}>
              <div className="row between wrap">
                <div>
                  <h3>{m.name} {m.strength && <span className="muted">{m.strength}</span>}</h3>
                  <div className="muted">For {m.memberName}{!m.active && ' | paused'}</div>
                </div>
                <div className="row">
                  <Link className="btn ghost small" to={`/medicines/${m.id}/edit`}>Edit</Link>
                  <button className="btn danger small" onClick={() => remove(m)}>Delete</button>
                </div>
              </div>

              <VerdictCard v={m.verification} compact />

              <dl className="facts">
                <div><dt>Batch</dt><dd>{m.batchNumber || '-'}</dd></div>
                <div><dt>Expires</dt><dd>{fmtDate(m.expiryDate)}</dd></div>
                <div><dt>Doses</dt><dd>{scheduled ? m.doseTimes.map(fmtTime24to12).join(', ') : 'As needed'}</dd></div>
                <div>
                  <dt>Stock</dt>
                  <dd className={low || m.tabletsRemaining === 0 ? 'bad-text' : ''}>
                    {m.tabletsRemaining} tablet(s){scheduled && ` (${m.daysLeft} day(s))`}
                  </dd>
                </div>
              </dl>

              {refillFor === m.id ? (
                <div className="row wrap">
                  <label className="inline">Tablets added
                    <input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} className="narrow" />
                  </label>
                  <button className="btn small" onClick={() => refill(m)}>Add stock</button>
                  <button className="btn ghost small" onClick={() => setRefillFor(null)}>Cancel</button>
                </div>
              ) : (
                <button className={`btn small ${low ? '' : 'ghost'}`} onClick={() => { setRefillFor(m.id); setQty(30) }}>
                  I refilled this
                </button>
              )}
            </article>
          )
        })}
      </div>
    </div>
  )
}
