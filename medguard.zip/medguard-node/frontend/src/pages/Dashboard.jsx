import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { useLoad } from '../hooks.js'
import { fmtTime24to12 } from '../utils.js'

const STATUS_LABEL = {
  TAKEN: 'Taken', SKIPPED: 'Skipped', MISSED: 'Missed', DUE: 'Due now', UPCOMING: 'Later today',
}

export default function Dashboard() {
  const { data, error, loading, reload } = useLoad(() => api.get('/dashboard'))
  const [actionError, setActionError] = useState('')
  const [pending, setPending] = useState('')

  async function logDose(d, status) {
    const key = `${d.medicineId}@${d.time}`
    setActionError('')
    setPending(key)
    try {
      await api.post(`/medicines/${d.medicineId}/doses`, { status, time: d.time })
      await reload()
    } catch (e) {
      setActionError(e.message)
    } finally {
      setPending('')
    }
  }

  if (loading && !data) return <p className="muted">Loading...</p>
  if (error) return <p className="error">{error}</p>

  const empty = data.memberCount === 0
  return (
    <div className="stack-lg">
      <h2>Today</h2>

      {empty && (
        <div className="card soft">
          <h3>Let's get started</h3>
          <ol className="steps">
            <li><Link to="/family">Add a family member</Link> (a parent, a child, or yourself).</li>
            <li><Link to="/medicines/new">Add their medicines</Link> by scanning the strip.</li>
            <li>MedGuard checks expiry, tracks doses and warns you before stock runs out.</li>
          </ol>
        </div>
      )}

      <div className="stats">
        <div className="stat"><span>{data.memberCount}</span>People</div>
        <div className="stat"><span>{data.medicineCount}</span>Medicines</div>
        <div className={`stat ${data.alerts.length ? 'stat-warn' : ''}`}><span>{data.alerts.length}</span>Alerts</div>
      </div>

      {data.alerts.length > 0 && (
        <section className="stack">
          <h3>Needs attention</h3>
          {data.alerts.map((a, i) => (
            <div key={i} className={`alert alert-${a.level.toLowerCase()}`}>
              <span>{a.message}</span>
              <Link to={`/medicines/${a.medicineId}/edit`} className="alert-link">Open</Link>
            </div>
          ))}
        </section>
      )}

      <section className="stack">
        <h3>Doses today</h3>
        {actionError && <p className="error">{actionError}</p>}
        {data.today.length === 0 ? (
          <p className="muted">No scheduled doses today. Set dose times on a medicine to get reminders.</p>
        ) : (
          data.today.map((d) => {
            const key = `${d.medicineId}@${d.time}`
            const open = d.status === 'DUE' || d.status === 'UPCOMING' || d.status === 'MISSED'
            return (
              <div key={key} className={`dose dose-${d.status.toLowerCase()}`}>
                <div className="dose-time">{fmtTime24to12(d.time)}</div>
                <div className="dose-body">
                  <strong>{d.medicineName}</strong>
                  <span className="muted">{d.memberName}</span>
                </div>
                <span className={`chip chip-${d.status === 'TAKEN' ? 'ok' : d.status === 'MISSED' ? 'bad' : d.status === 'DUE' ? 'warn' : 'muted'}`}>
                  {STATUS_LABEL[d.status]}
                </span>
                {open && (
                  <div className="dose-actions">
                    <button className="btn small" disabled={pending === key} onClick={() => logDose(d, 'TAKEN')}>Taken</button>
                    {d.status !== 'MISSED' && (
                      <button className="btn ghost small" disabled={pending === key} onClick={() => logDose(d, 'SKIPPED')}>Skip</button>
                    )}
                  </div>
                )}
              </div>
            )
          })
        )}
      </section>
    </div>
  )
}
