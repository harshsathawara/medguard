import { useState } from 'react'
import { useAuth } from '../auth.jsx'

export default function Login() {
  const { login, register } = useAuth()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      if (mode === 'login') await login(form.email, form.password)
      else await register(form)
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card card">
        <div className="auth-brand"><span className="logo big">✚</span><h1>MedGuard</h1></div>
        <p className="muted center-text">
          Check medicines before you use them. Never miss a dose or a refill for the people you care for.
        </p>

        <form onSubmit={submit} className="stack">
          {mode === 'register' && (
            <label>Your name
              <input value={form.name} onChange={set('name')} required autoComplete="name" />
            </label>
          )}
          <label>Email
            <input type="email" value={form.email} onChange={set('email')} required autoComplete="email" />
          </label>
          <label>Password
            <input type="password" value={form.password} onChange={set('password')} required minLength={mode === 'register' ? 8 : 1}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
            {mode === 'register' && <span className="hint">At least 8 characters</span>}
          </label>
          {mode === 'register' && (
            <label>Your phone <span className="hint">(optional, for alerts)</span>
              <input value={form.phone} onChange={set('phone')} inputMode="tel" autoComplete="tel" />
            </label>
          )}
          {error && <p className="error" role="alert">{error}</p>}
          <button className="btn block" disabled={busy}>
            {busy ? 'Please wait...' : mode === 'login' ? 'Log in' : 'Create account'}
          </button>
        </form>

        <p className="center-text">
          {mode === 'login' ? 'New here? ' : 'Already have an account? '}
          <button className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError('') }}>
            {mode === 'login' ? 'Create an account' : 'Log in'}
          </button>
        </p>
      </div>
    </div>
  )
}
