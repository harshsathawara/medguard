import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import Scanner from '../components/Scanner.jsx'
import VerdictCard from '../components/VerdictCard.jsx'

/** Quick check of a strip before buying or using it. Nothing is saved. */
export default function Check() {
  const [form, setForm] = useState({ medicineName: '', batchNumber: '', expiryDate: '', code: '' })
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  async function check(e) {
    e.preventDefault()
    setError('')
    setResult(null)
    if (!form.batchNumber && !form.expiryDate && !form.code) {
      setError('Enter a batch number or expiry date, or scan the strip.')
      return
    }
    setBusy(true)
    try {
      setResult(await api.post('/verify', {
        medicineName: form.medicineName || null,
        batchNumber: form.batchNumber || null,
        expiryDate: form.expiryDate || null,
        code: form.code || null,
      }))
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  const reportLink = `/reports?name=${encodeURIComponent(form.medicineName)}&batch=${encodeURIComponent(form.batchNumber)}`

  return (
    <div className="stack-lg">
      <h2>Check a strip</h2>
      <p className="muted">Before you buy or take a medicine, check its expiry and whether others have reported that batch.</p>

      <Scanner
        onCode={(code) => setForm((f) => ({ ...f, code }))}
        onText={(t) => setForm((f) => ({ ...f, batchNumber: t.batchNumber || f.batchNumber, expiryDate: t.expiryDate || f.expiryDate }))}
      />

      <form className="card stack" onSubmit={check}>
        <div className="grid2">
          <label>Medicine name <span className="hint">(optional)</span>
            <input value={form.medicineName} onChange={set('medicineName')} />
          </label>
          <label>Batch number
            <input value={form.batchNumber} onChange={set('batchNumber')} />
          </label>
          <label>Expiry date
            <input type="date" value={form.expiryDate} onChange={set('expiryDate')} />
          </label>
          {form.code && (
            <label>Scanned code
              <input value={form.code} readOnly />
            </label>
          )}
        </div>
        {error && <p className="error">{error}</p>}
        <button className="btn" disabled={busy}>{busy ? 'Checking...' : 'Check this strip'}</button>
      </form>

      {result && (
        <div className="stack">
          <VerdictCard v={result} />
          {result.verdict !== 'SAFE' && form.batchNumber && (
            <Link className="btn ghost" to={reportLink}>Report this batch as suspicious</Link>
          )}
        </div>
      )}
    </div>
  )
}
