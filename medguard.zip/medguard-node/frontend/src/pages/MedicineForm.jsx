import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { api } from '../api.js'
import { useLoad } from '../hooks.js'
import Scanner from '../components/Scanner.jsx'
import VerdictCard from '../components/VerdictCard.jsx'

const blank = {
  memberId: '', name: '', strength: '', batchNumber: '', expiryDate: '', scanCode: '',
  doseTimes: ['08:00'], tabletsPerDose: 1, tabletsRemaining: 30, refillLeadDays: 7, notes: '', active: true,
}

export default function MedicineForm() {
  const { id } = useParams()
  const editing = !!id
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const members = useLoad(() => api.get('/members'))
  const [form, setForm] = useState(blank)
  const [loaded, setLoaded] = useState(!editing)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [preview, setPreview] = useState(null)
  const [asNeeded, setAsNeeded] = useState(false)

  // Load the medicine when editing.
  useEffect(() => {
    if (!editing) return
    api.get(`/medicines/${id}`)
      .then((m) => {
        setForm({
          memberId: m.memberId, name: m.name, strength: m.strength || '', batchNumber: m.batchNumber || '',
          expiryDate: m.expiryDate || '', scanCode: m.scanCode || '',
          doseTimes: m.doseTimes.length ? m.doseTimes : ['08:00'],
          tabletsPerDose: m.tabletsPerDose, tabletsRemaining: m.tabletsRemaining,
          refillLeadDays: m.refillLeadDays, notes: m.notes || '', active: m.active,
        })
        setAsNeeded(m.doseTimes.length === 0)
        setLoaded(true)
      })
      .catch((e) => setError(e.message))
  }, [id, editing])

  // Default the person when adding.
  useEffect(() => {
    if (editing || form.memberId || !members.data?.length) return
    const wanted = Number(params.get('memberId'))
    const pick = members.data.find((m) => m.id === wanted) || members.data[0]
    setForm((f) => ({ ...f, memberId: pick.id }))
  }, [members.data, editing, form.memberId, params])

  // Live safety check while the user types / scans.
  useEffect(() => {
    if (!form.batchNumber && !form.expiryDate) { setPreview(null); return }
    const t = setTimeout(() => {
      api.post('/verify', {
        batchNumber: form.batchNumber || null,
        expiryDate: form.expiryDate || null,
        code: form.scanCode || null,
      }).then(setPreview).catch(() => setPreview(null))
    }, 400)
    return () => clearTimeout(t)
  }, [form.batchNumber, form.expiryDate, form.scanCode])

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })
  const setTime = (i, v) => setForm({ ...form, doseTimes: form.doseTimes.map((t, j) => (j === i ? v : t)) })

  async function submit(e) {
    e.preventDefault()
    setError('')
    if (!form.memberId) { setError('Choose who this medicine is for.'); return }
    setBusy(true)
    try {
      const times = asNeeded ? [] : form.doseTimes.filter(Boolean)
      const payload = {
        ...form,
        memberId: Number(form.memberId),
        strength: form.strength || null,
        batchNumber: form.batchNumber || null,
        expiryDate: form.expiryDate || null,
        scanCode: form.scanCode || null,
        notes: form.notes || null,
        doseTimes: times,
        dosesPerDay: Math.max(1, times.length),
        tabletsPerDose: Number(form.tabletsPerDose),
        tabletsRemaining: Number(form.tabletsRemaining),
        refillLeadDays: Number(form.refillLeadDays),
      }
      if (editing) await api.put(`/medicines/${id}`, payload)
      else await api.post('/medicines', payload)
      navigate('/medicines')
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  if (members.data && members.data.length === 0) {
    return (
      <div className="card soft">
        <p>Add a family member first, then you can add their medicines.</p>
        <Link className="btn" to="/family">Add a family member</Link>
      </div>
    )
  }
  if (!loaded) return error ? <p className="error">{error}</p> : <p className="muted">Loading...</p>

  return (
    <form className="stack-lg" onSubmit={submit}>
      <h2>{editing ? 'Edit medicine' : 'Add a medicine'}</h2>

      {!editing && (
        <Scanner
          onCode={(code) => setForm((f) => ({ ...f, scanCode: code }))}
          onText={(t) => setForm((f) => ({
            ...f,
            batchNumber: t.batchNumber || f.batchNumber,
            expiryDate: t.expiryDate || f.expiryDate,
          }))}
        />
      )}

      <section className="card stack">
        <h3>Medicine</h3>
        <div className="grid2">
          <label>For
            <select value={form.memberId} onChange={set('memberId')} required>
              {members.data?.map((m) => <option key={m.id} value={m.id}>{m.name}{m.relation ? ` (${m.relation})` : ''}</option>)}
            </select>
          </label>
          <label>Medicine name
            <input value={form.name} onChange={set('name')} required placeholder="e.g. Amlodipine" />
          </label>
          <label>Strength
            <input value={form.strength} onChange={set('strength')} placeholder="e.g. 5 mg" />
          </label>
          <label>Batch number
            <input value={form.batchNumber} onChange={set('batchNumber')} placeholder="From the strip: B.No." />
          </label>
          <label>Expiry date
            <input type="date" value={form.expiryDate} onChange={set('expiryDate')} />
            <span className="hint">Strips print month/year. Use the last day of that month.</span>
          </label>
          {form.scanCode && (
            <label>Scanned code
              <div className="row">
                <input value={form.scanCode} readOnly />
                <button type="button" className="btn ghost small" onClick={() => setForm({ ...form, scanCode: '' })}>Clear</button>
              </div>
            </label>
          )}
        </div>
        {preview && <VerdictCard v={preview} />}
      </section>

      <section className="card stack">
        <h3>How it is taken</h3>
        <label className="check">
          <input type="checkbox" checked={asNeeded} onChange={(e) => setAsNeeded(e.target.checked)} />
          Only when needed (no fixed times)
        </label>
        {!asNeeded && (
          <div className="stack">
            <span>Dose times</span>
            {form.doseTimes.map((t, i) => (
              <div key={i} className="row">
                <input type="time" value={t} onChange={(e) => setTime(i, e.target.value)} required />
                {form.doseTimes.length > 1 && (
                  <button type="button" className="btn ghost small" onClick={() => setForm({ ...form, doseTimes: form.doseTimes.filter((_, j) => j !== i) })}>Remove</button>
                )}
              </div>
            ))}
            <div>
              <button type="button" className="btn ghost small" onClick={() => setForm({ ...form, doseTimes: [...form.doseTimes, '20:00'] })}>+ Add a time</button>
            </div>
          </div>
        )}
        <div className="grid2">
          <label>Tablets per dose
            <input type="number" min="1" max="20" value={form.tabletsPerDose} onChange={set('tabletsPerDose')} required />
          </label>
          <label>Tablets left now
            <input type="number" min="0" value={form.tabletsRemaining} onChange={set('tabletsRemaining')} required />
          </label>
          <label>Warn me when this many days are left
            <input type="number" min="0" max="60" value={form.refillLeadDays} onChange={set('refillLeadDays')} />
          </label>
        </div>
        <label>Notes
          <textarea rows="2" value={form.notes} onChange={set('notes')} placeholder="e.g. after food, prescribed by Dr. Shah" />
        </label>
        {editing && (
          <label className="check">
            <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
            Currently taking this (untick to pause reminders)
          </label>
        )}
      </section>

      {error && <p className="error" role="alert">{error}</p>}
      <div className="row">
        <button className="btn" disabled={busy}>{busy ? 'Saving...' : 'Save medicine'}</button>
        <Link className="btn ghost" to="/medicines">Cancel</Link>
      </div>
    </form>
  )
}
