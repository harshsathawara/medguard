# MedGuard

Medicine safety and refill tracker. Scan a strip to check its expiry and community reports, track doses for family members, and get warned before stock runs out.

**Stack:** React (Vite) | Node.js + Express | PostgreSQL

## What it does

- **Check a strip:** read the barcode/QR with the camera, or photograph the printed batch number and expiry date (read in the browser with OCR). The app flags expired and near-expiry medicine, and batches that several different users reported as suspicious.
- **Family members:** a caregiver manages medicines for parents, children or themselves.
- **Dose schedule:** dose times per medicine, a "Today" screen with Taken / Skip buttons. A dose nobody answers is marked *missed* an hour later (configurable) and the caregiver is alerted.
- **Refills:** stock goes down each time a dose is taken. A refill alert appears when the remaining days drop below a threshold you choose per medicine.
- **Community reports:** a batch is flagged once `SUSPICIOUS_THRESHOLD` (default 3) *different* users report it. One person cannot flag a batch alone.
- **Notifications:** in-app list, plus a pluggable SMS/WhatsApp channel (see below).

### What "authenticity" means here

A photo or barcode alone cannot prove a medicine is genuine. Real authenticity needs a trusted data source: a manufacturer API, a regulator's code-verification service, or a GS1 lookup.

Out of the box MedGuard checks **expiry** and **community reports**, and says plainly *"could not verify against an official registry"*. To add real verification, implement `lookup({ code, batchNumber })` in `backend/src/extensions.js` (`createRegistry`). It must return `VERIFIED`, `NOT_FOUND` or `UNAVAILABLE`; the verdict logic already handles all three. Check which registries exist in each country you launch in.

## Project layout

```
medguard/
  docker-compose.yml        PostgreSQL + backend + frontend
  .env.example              copy to .env
  backend/                  Express API
    src/
      server.js             start-up (config, migrate, listen, scheduler)
      app.js                Express app and routes wiring
      schema.sql            the PostgreSQL tables (idempotent)
      routes/               auth, members, medicines (+doses), dashboard, misc
      services/             medicine views, notifications
      verification.js       expiry / reports / registry verdict
      scheduler.js          reminders, missed doses, daily alerts
      extensions.js         message channel + authenticity registry (replace these)
    test/flow.test.js       end-to-end tests against real PostgreSQL
  frontend/                 React app (Vite)
    src/pages/              Dashboard, Medicines, MedicineForm, Family, Check, Reports, Notifications
    src/components/         Scanner (camera + OCR), VerdictCard, Layout
```

## Run it with Docker (easiest)

```bash
cp .env.example .env          # then edit the password and the JWT secret
docker compose up --build
```

Open http://localhost:3000 and create an account.

## Run it for development

You need Node 18+ and PostgreSQL 14+.

```bash
# 1. Database (Docker shortcut; or use your own PostgreSQL)
cp .env.example .env
docker compose up -d db

# 2. Backend  ->  http://localhost:8080   (creates the tables on first start)
cd backend
npm install
DB_PASSWORD=change-me-db-password npm run dev    # use the DB_PASSWORD from your .env

# 3. Frontend  ->  http://localhost:5173   (proxies /api to :8080)
cd ../frontend
npm install
npm run dev
```

With your own PostgreSQL, create a database and user, then set `DATABASE_URL` (for example `postgres://user:pass@localhost:5432/medguard`) or the separate `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`.

### Camera note

Browsers only allow camera access on `https://` or `http://localhost`. For a phone test, serve the app over HTTPS (a tunnel, or a reverse proxy with a certificate). "Read text from a photo" works without live camera access.

## Tests

```bash
createdb medguard_test        # a throwaway database whose name contains "test"
cd backend
TEST_DATABASE_URL=postgres://medguard:YOUR_PASSWORD@localhost:5432/medguard_test npm test
```

The tests **drop and recreate the tables** in that database, so never point them at real data (the runner refuses unless the name contains "test").

## Configuration (backend environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `DATABASE_URL` | (unset) | Full connection string. If unset, the `DB_*` values below are used |
| `DB_HOST` / `DB_PORT` / `DB_NAME` / `DB_USER` / `DB_PASSWORD` | `localhost` / `5432` / `medguard` / `medguard` / `medguard` | Separate settings |
| `JWT_SECRET` | dev value | **Required when `NODE_ENV=production`.** At least 32 characters |
| `APP_TIMEZONE` | `Asia/Kolkata` | Zone for dose times and the daily 09:00 job |
| `PORT` | `8080` | API port |
| `CORS_ORIGINS` | `http://localhost:5173,http://localhost:3000` | Allowed browser origins |
| `SUSPICIOUS_THRESHOLD` | `3` | Different users needed to flag a batch |
| `MISSED_AFTER_MINUTES` | `60` | When an unanswered dose counts as missed |
| `SCHEDULER_ENABLED` | `true` | Set `false` to turn the background jobs off |
| `AUTH_RATE_LIMIT` | `30` | Login/register attempts per IP per 15 minutes |
| `TRUST_PROXY` | `0` | Set `1` behind nginx or another reverse proxy |

## REST API (all under `/api`, JWT in `Authorization: Bearer ...`)

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/register`, `/auth/login` | Create account / log in, returns a token |
| GET | `/auth/me` | Current user |
| GET | `/health` | Liveness and database check (public) |
| GET/POST | `/members` | List / add family members |
| PUT/DELETE | `/members/:id` | Edit / delete (their medicines are deleted too) |
| GET/POST | `/medicines` (`?memberId=`) | List / add medicines |
| GET/PUT/DELETE | `/medicines/:id` | One medicine |
| POST | `/medicines/:id/refill` | Add stock `{quantity}` |
| POST/GET | `/medicines/:id/doses` | Log a dose `{status, time}` / history |
| POST | `/verify` | Check `{batchNumber, expiryDate, code}` without saving |
| GET/POST | `/reports` | Your suspicious-batch reports / submit one |
| GET | `/dashboard` | Alerts and today's doses |
| GET | `/notifications`, POST `/notifications/seen-all`, `/notifications/:id/seen` | Notifications |

Every query is scoped to the logged-in user, so one account can never read another's data (covered by tests). Errors always look like `{"error": "message"}`.

## Reminders

`scheduler.js` runs inside the API process:

- **Every minute:** sends a dose reminder at the scheduled time (to the person's phone, if given). After `MISSED_AFTER_MINUTES` with no answer it records the dose as missed and alerts the caregiver. Doses that were due before the medicine was added are not counted, and stale misses (for example after the server was down for hours) are not reported.
- **Daily at 09:00, and once at start-up:** refill and expiry alerts, at most one per medicine per type per day.

If you run more than one API instance, run the scheduler on only one of them (`SCHEDULER_ENABLED=false` on the others), or move it to a separate worker process.

Messages go through `createChannel()` in `backend/src/extensions.js`. The default only logs. Replace it with Twilio, MSG91, the WhatsApp Cloud API or FCM. WhatsApp requires approved message templates for business-initiated messages.

## Before you put this in front of real users

- **Health data is sensitive.** Use HTTPS, a strong `JWT_SECRET`, a managed PostgreSQL with backups, and a locked-down database firewall (the compose file exposes port 5432 for development; remove that for production). Get clear consent and publish a privacy policy. Check the rules that apply to you (India's DPDP Act, GDPR, and so on).
- **Schema changes:** `schema.sql` only creates missing tables. When the schema starts changing, adopt a migration tool (node-pg-migrate, Knex or Prisma Migrate).
- **Not medical advice:** the app tracks and warns. It does not replace a doctor or pharmacist. Keep wording like "check before using" rather than promising a medicine is safe.
- **Not built yet:** password reset, email verification, push notifications, an installable offline PWA, multi-caregiver sharing, and an admin view for moderating reports. Tokens are kept in the browser's localStorage; for higher security move them to httpOnly cookies.

## Verification status of this code

Checked where this was generated:

- **Backend:** 11 end-to-end tests pass against a real PostgreSQL 16 database (sign-up and login, validation errors, medicines and doses, stock, the dashboard, expiry and report verdicts, data isolation between users, cascade deletes, missed-dose and daily jobs). One rule was deliberately broken to confirm the tests catch it.
- **Whole app:** the real React app, real API and real PostgreSQL were driven in a browser through sign-up, adding a person and a medicine, marking a dose, stock going down, flagging an expired strip, reporting a batch, and logging out and in again.

Not checked:

- Docker builds (`docker compose up --build`) were not run, because there was no Docker daemon.
- Live camera scanning and OCR were not tried on a real phone or with a real strip photo; only the text-parsing code was checked with sample strings. Test with a few real strips before relying on it.
- Sending real SMS/WhatsApp messages (only the log channel exists until you add a provider).
