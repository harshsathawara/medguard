// End-to-end tests against a real PostgreSQL database.
//
//   createdb medguard_test
//   TEST_DATABASE_URL=postgres://medguard:medguard@localhost:5432/medguard_test npm test
//
// The schema in that database is DROPPED and recreated on every run, so use a throwaway database.
import assert from 'node:assert/strict'
import test, { after, before, describe } from 'node:test'
import request from 'supertest'
import { createApp } from '../src/app.js'
import { loadConfig } from '../src/config.js'
import { createPool, migrate } from '../src/db.js'
import { createRegistry } from '../src/extensions.js'
import { dailyChecks, everyMinute } from '../src/scheduler.js'
import { addDays, localEpochMin, zoned } from '../src/time.js'

const url = process.env.TEST_DATABASE_URL

if (!url) {
  test('integration tests', { skip: 'set TEST_DATABASE_URL to a throwaway database whose name contains "test"' }, () => {})
} else {
  if (!/test/i.test(new URL(url).pathname)) {
    throw new Error('Refusing to run: TEST_DATABASE_URL must point to a database whose name contains "test" (its tables are dropped).')
  }

  const config = loadConfig({ schedulerEnabled: false, authRateLimit: 1000, timezone: 'Asia/Kolkata' })
  const pool = createPool(url)
  const sent = []
  const channel = { async send(to, text) { sent.push({ to, text }) } }
  const deps = { pool, config, channel, registry: createRegistry() }
  const app = createApp(deps)

  const call = (method, path, token, body) => {
    let r = request(app)[method](path)
    if (token) r = r.set('Authorization', `Bearer ${token}`)
    return body === undefined ? r : r.send(body)
  }
  const register = async (email, extra = {}) => {
    const res = await call('post', '/api/auth/register', null, { name: `User ${email}`, email, password: 'password123', ...extra })
    assert.equal(res.status, 200, JSON.stringify(res.body))
    return res.body.token
  }
  const plusDays = (n) => addDays(zoned(config.timezone).date, n)

  before(async () => {
    await pool.query('drop schema public cascade; create schema public;')
    await migrate(pool)
    await migrate(pool) // running it twice must be harmless
  })
  after(() => pool.end())

  describe('auth and validation', () => {
    test('register, duplicate, login, me', async () => {
      const token = await register('auth@example.com')
      assert.equal((await call('post', '/api/auth/register', null, { name: 'X', email: 'AUTH@example.com', password: 'password123' })).status, 409)
      assert.equal((await call('post', '/api/auth/login', null, { email: 'auth@example.com', password: 'wrong-password' })).status, 401)
      assert.equal((await call('post', '/api/auth/login', null, { email: 'nobody@example.com', password: 'password123' })).status, 401)
      const login = await call('post', '/api/auth/login', null, { email: 'Auth@Example.com', password: 'password123' })
      assert.equal(login.status, 200)
      const me = await call('get', '/api/auth/me', login.body.token)
      assert.equal(me.body.email, 'auth@example.com')
      assert.ok(token)
    })

    test('rejects bad input with readable 400s', async () => {
      const short = await call('post', '/api/auth/register', null, { name: 'A', email: 'a@b.co', password: 'short' })
      assert.equal(short.status, 400)
      assert.match(short.body.error, /password/)
      const token = await register('valid@example.com')
      const badTime = await call('post', '/api/members', token, { name: 'Papa' })
      const med = await call('post', '/api/medicines', token, {
        memberId: badTime.body.id, name: 'X', doseTimes: ['25:99'] })
      assert.equal(med.status, 400)
      assert.match(med.body.error, /HH:mm/)
    })

    test('401 without or with a bad token, 400 for broken JSON, 404 for unknown routes', async () => {
      assert.equal((await call('get', '/api/members')).status, 401)
      assert.equal((await call('get', '/api/members', 'not-a-token')).status, 401)
      const token = await register('errors@example.com')
      const broken = await request(app).post('/api/members').set('Authorization', `Bearer ${token}`)
        .set('Content-Type', 'application/json').send('{"name": ')
      assert.equal(broken.status, 400)
      assert.equal((await call('get', '/api/nope', token)).status, 404)
      assert.equal((await call('get', '/api/medicines/abc', token)).status, 404)
      assert.equal((await call('get', '/api/health')).body.status, 'ok')
    })
  })

  describe('medicines, doses, verification', () => {
    test('main flow', async () => {
      const token = await register('flow@example.com')
      const member = (await call('post', '/api/members', token, { name: 'Papa', relation: 'Father' })).body
      assert.equal(member.medicineCount, 0)

      const expiry = plusDays(365)
      const created = await call('post', '/api/medicines', token, {
        memberId: member.id, name: 'Amlodipine', strength: '5 mg', batchNumber: 'AB1234', expiryDate: expiry,
        doseTimes: ['20:00', '08:00'], tabletsPerDose: 1, tabletsRemaining: 10,
      })
      assert.equal(created.status, 200, JSON.stringify(created.body))
      const med = created.body
      assert.equal(med.expiryDate, expiry, 'DATE must round-trip without shifting a day')
      assert.deepEqual(med.doseTimes, ['08:00', '20:00'])
      assert.equal(med.dosesPerDay, 2)
      assert.equal(med.daysLeft, 5)
      assert.equal(med.verification.verdict, 'SAFE')
      assert.equal(med.verification.authenticity, 'UNAVAILABLE')

      // taking a dose reduces stock; the same slot cannot be logged twice
      const dose = await call('post', `/api/medicines/${med.id}/doses`, token, { status: 'TAKEN', time: '08:00' })
      assert.equal(dose.status, 200, JSON.stringify(dose.body))
      assert.equal((await call('get', `/api/medicines/${med.id}`, token)).body.tabletsRemaining, 9)
      assert.equal((await call('post', `/api/medicines/${med.id}/doses`, token, { status: 'TAKEN', time: '08:00' })).status, 409)
      assert.equal((await call('get', `/api/medicines/${med.id}/doses`, token)).body.length, 1)

      // dashboard: low stock alert (4 days <= 7) and today's slots
      const dash = (await call('get', '/api/dashboard', token)).body
      assert.equal(dash.memberCount, 1)
      assert.equal(dash.medicineCount, 1)
      assert.equal(dash.today.length, 2)
      assert.equal(dash.today.find((d) => d.time === '08:00').status, 'TAKEN')
      assert.ok(dash.alerts.some((a) => a.type === 'REFILL'))

      // refill, edit, list filter
      const refilled = (await call('post', `/api/medicines/${med.id}/refill`, token, { quantity: 30 })).body
      assert.equal(refilled.tabletsRemaining, 39)
      assert.equal((await call('post', `/api/medicines/${med.id}/refill`, token, { quantity: 0 })).status, 400)
      const edited = await call('put', `/api/medicines/${med.id}`, token, {
        memberId: member.id, name: 'Amlodipine', doseTimes: [], tabletsRemaining: 39 })
      assert.equal(edited.body.doseTimes.length, 0, 'empty list means as-needed')
      assert.equal((await call('get', `/api/medicines?memberId=${member.id}`, token)).body.length, 1)
      assert.equal((await call('get', '/api/members', token)).body[0].medicineCount, 1)

      // deleting the member cascades to medicines and dose logs
      assert.equal((await call('delete', `/api/members/${member.id}`, token)).status, 204)
      assert.equal((await call('get', '/api/medicines', token)).body.length, 0)
      const { rows } = await pool.query('select count(*)::int as n from dose_logs where medicine_id = $1', [med.id])
      assert.equal(rows[0].n, 0)
    })

    test('stock never goes below zero', async () => {
      const token = await register('stock@example.com')
      const m = (await call('post', '/api/members', token, { name: 'Me' })).body
      const med = (await call('post', '/api/medicines', token, { memberId: m.id, name: 'Pill', doseTimes: ['08:00'], tabletsPerDose: 2, tabletsRemaining: 1 })).body
      await call('post', `/api/medicines/${med.id}/doses`, token, { status: 'TAKEN' })
      assert.equal((await call('get', `/api/medicines/${med.id}`, token)).body.tabletsRemaining, 0)
      const dash = (await call('get', '/api/dashboard', token)).body
      assert.ok(dash.alerts.some((a) => a.type === 'OUT_OF_STOCK'))
    })

    test('expired strip is DANGER', async () => {
      const token = await register('expired@example.com')
      const res = await call('post', '/api/verify', token, { batchNumber: 'OLD1', expiryDate: plusDays(-3) })
      assert.equal(res.body.verdict, 'DANGER')
      assert.equal(res.body.expiry, 'EXPIRED')
      assert.equal(res.body.daysToExpiry, -3)
      const soon = await call('post', '/api/verify', token, { batchNumber: 'SOON', expiryDate: plusDays(10) })
      assert.equal(soon.body.verdict, 'CAUTION')
      const none = await call('post', '/api/verify', token, {})
      assert.equal(none.body.verdict, 'CAUTION')
      assert.equal((await call('post', '/api/verify', token, { expiryDate: '2026-13-45' })).status, 400)
    })

    test('a batch is suspicious only after several different users report it', async () => {
      const a = await register('r1@example.com')
      const rep = { medicineName: 'Fakecillin', batchNumber: 'FAKE-9' }
      assert.equal((await call('post', '/api/reports', a, rep)).status, 200)
      assert.equal((await call('post', '/api/reports', a, { ...rep, batchNumber: 'fake-9' })).status, 409, 'same user, same batch')
      const input = { batchNumber: 'fake-9', expiryDate: plusDays(400) }
      assert.equal((await call('post', '/api/verify', a, input)).body.batch, 'REPORTED')
      for (const email of ['r2@example.com', 'r3@example.com']) {
        assert.equal((await call('post', '/api/reports', await register(email), rep)).status, 200)
      }
      const flagged = (await call('post', '/api/verify', a, input)).body
      assert.equal(flagged.batch, 'SUSPICIOUS')
      assert.equal(flagged.reportCount, 3)
      assert.equal(flagged.verdict, 'DANGER')
      assert.equal((await call('get', '/api/reports', a)).body.length, 1, 'users only see their own reports')
    })

    test('users cannot see or change each other\'s data', async () => {
      const owner = await register('owner@example.com')
      const other = await register('other@example.com')
      const m = (await call('post', '/api/members', owner, { name: 'Mine' })).body
      const med = (await call('post', '/api/medicines', owner, { memberId: m.id, name: 'Private' })).body
      assert.equal((await call('get', `/api/medicines/${med.id}`, other)).status, 404)
      assert.equal((await call('delete', `/api/medicines/${med.id}`, other)).status, 404)
      assert.equal((await call('post', `/api/medicines/${med.id}/doses`, other, { status: 'TAKEN' })).status, 404)
      assert.equal((await call('post', `/api/medicines/${med.id}/refill`, other, { quantity: 5 })).status, 404)
      assert.equal((await call('put', `/api/members/${m.id}`, other, { name: 'Hacked' })).status, 404)
      assert.equal((await call('post', '/api/medicines', other, { memberId: m.id, name: 'Sneaky' })).status, 404)
      assert.equal((await call('get', '/api/members', other)).body.length, 0)
      assert.equal((await call('get', '/api/medicines', other)).body.length, 0)
    })
  })

  describe('background jobs', () => {
    test('missed doses are recorded once, alert the caregiver, and can be corrected', async () => {
      const token = await register('sched@example.com', { phone: '+910000000001' })
      const m = (await call('post', '/api/members', token, { name: 'Mummy', phone: '+910000000002' })).body
      const med = (await call('post', '/api/medicines', token, {
        memberId: m.id, name: 'Metformin', strength: '500 mg', doseTimes: ['10:00'], tabletsPerDose: 1, tabletsRemaining: 20 })).body
      // pretend the medicine was added yesterday so that today's 10:00 slot counts
      await pool.query('update medicines set created_at = now() - interval \'2 days\' where id = $1', [med.id])

      const today = zoned(config.timezone).date
      const at = (hhmm) => ({ date: today, time: hhmm, dateTime: `${today}T${hhmm}:00`, epochMin: localEpochMin(today, hhmm) })

      sent.length = 0
      await everyMinute(deps, at('10:00')) // dose time: the person gets a reminder
      assert.ok(sent.some((s) => s.to === '+910000000002' && /Metformin/.test(s.text)), 'reminder sent to the person')

      await everyMinute(deps, at('10:30')) // not overdue yet
      assert.equal((await call('get', '/api/notifications', token)).body.length, 0)

      await everyMinute(deps, at('11:00')) // 60 minutes late: missed
      await everyMinute(deps, at('11:01')) // running again must not duplicate
      const notes = (await call('get', '/api/notifications', token)).body
      assert.equal(notes.length, 1)
      assert.equal(notes[0].type, 'DOSE_MISSED')
      assert.ok(sent.some((s) => s.to === '+910000000001' && /not taken Metformin/.test(s.text)), 'caregiver messaged')
      const dash = (await call('get', '/api/dashboard', token)).body
      assert.equal(dash.unreadNotifications, 1)

      // the caregiver can still correct it afterwards, which also reduces stock
      const fix = await call('post', `/api/medicines/${med.id}/doses`, token, { status: 'TAKEN', time: '10:00' })
      assert.equal(fix.status, 200)
      assert.equal(fix.body.status, 'TAKEN')
      assert.equal((await call('get', `/api/medicines/${med.id}`, token)).body.tabletsRemaining, 19)

      // mark as read
      assert.equal((await call('post', `/api/notifications/${notes[0].id}/seen`, token)).status, 204)
      assert.equal((await call('post', '/api/notifications/seen-all', token)).status, 204)
      assert.equal((await call('get', '/api/dashboard', token)).body.unreadNotifications, 0)
    })

    test('doses that were due before the medicine was added are not "missed"', async () => {
      const token = await register('fresh@example.com')
      const m = (await call('post', '/api/members', token, { name: 'New' })).body
      const med = (await call('post', '/api/medicines', token, { memberId: m.id, name: 'Fresh', doseTimes: ['00:01'], tabletsRemaining: 5 })).body
      const today = zoned(config.timezone).date
      await everyMinute(deps, { date: today, time: '03:00', dateTime: `${today}T03:00:00`, epochMin: localEpochMin(today, '03:00') })
      assert.equal((await call('get', '/api/notifications', token)).body.length, 0)
      assert.ok(med.id)
    })

    test('daily refill and expiry alerts are sent once per day', async () => {
      const token = await register('daily@example.com')
      const m = (await call('post', '/api/members', token, { name: 'Dad' })).body
      await call('post', '/api/medicines', token, {
        memberId: m.id, name: 'Statin', doseTimes: ['21:00'], tabletsPerDose: 1, tabletsRemaining: 3, expiryDate: plusDays(10) })
      await dailyChecks(deps)
      await dailyChecks(deps)
      const notes = (await call('get', '/api/notifications', token)).body
      assert.deepEqual(notes.map((n) => n.type).sort(), ['EXPIRY', 'REFILL'])
    })
  })
}
