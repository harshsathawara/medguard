import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import pg from 'pg'

// Return DATE as "YYYY-MM-DD" and TIMESTAMP (without time zone) as "YYYY-MM-DDTHH:mm:ss" strings.
// Left alone, node-postgres turns them into JS Dates in the server's time zone, which shifts days.
pg.types.setTypeParser(1082, (v) => v)
pg.types.setTypeParser(1114, (v) => v.replace(' ', 'T').slice(0, 19))

const here = path.dirname(fileURLToPath(import.meta.url))

/** `options` is a connection string or a node-postgres config object. */
export function createPool(options) {
  const base = typeof options === 'string' ? { connectionString: options } : options
  const pool = new pg.Pool({ ...base, max: 10 })
  pool.on('error', (err) => console.error('Unexpected database error', err.message))
  return pool
}

/** Runs fn(client) inside a transaction. */
export async function tx(pool, fn) {
  const client = await pool.connect()
  try {
    await client.query('begin')
    const result = await fn(client)
    await client.query('commit')
    return result
  } catch (err) {
    try { await client.query('rollback') } catch { /* connection already broken */ }
    throw err
  } finally {
    client.release()
  }
}

/** Creates the tables if they do not exist. Safe to run on every start. */
export async function migrate(pool) {
  const sql = fs.readFileSync(path.join(here, 'schema.sql'), 'utf8')
  const client = await pool.connect()
  try {
    await client.query('select pg_advisory_lock(727274)') // two instances starting together will not race
    await client.query(sql)
  } finally {
    try { await client.query('select pg_advisory_unlock(727274)') } catch { /* ignore */ }
    client.release()
  }
}
