// Two extension points. Replace these with real implementations when you are ready.

/**
 * Outbound messages (SMS / WhatsApp / push). The default only logs.
 * Swap in Twilio, MSG91, the WhatsApp Cloud API or FCM by returning an object with the same shape.
 * Note: WhatsApp requires pre-approved templates for business-initiated messages.
 */
export function createChannel(log = console) {
  return {
    async send(to, text) {
      log.info(`[message -> ${to}] ${text}`)
    },
  }
}

/**
 * Authenticity registry. A photo or barcode alone cannot prove a medicine is genuine: that needs a
 * trusted source such as a manufacturer API, a regulator's code-verification service or a GS1 lookup.
 *
 * lookup({ code, batchNumber }) must resolve to one of:
 *   'VERIFIED'    the registry confirmed it
 *   'NOT_FOUND'   the registry does not know it (possible fake)
 *   'UNAVAILABLE' no registry is configured or it could not be reached
 *
 * The default has no registry, so the app says "could not verify" instead of guessing.
 */
export function createRegistry() {
  return {
    async lookup() {
      return 'UNAVAILABLE'
    },
  }
}
