/** Stores an in-app notification and also pushes it to the caregiver's phone, if they gave one. */
export async function notifyCaregiver({ pool, channel }, ownerId, medicineId, type, message) {
  await pool.query(
    'insert into notifications (owner_id, medicine_id, type, message) values ($1, $2, $3, $4)',
    [ownerId, medicineId, type, message],
  )
  const { rows } = await pool.query('select phone from app_users where id = $1', [ownerId])
  if (rows[0]?.phone) {
    try {
      await channel.send(rows[0].phone, message)
    } catch (err) {
      console.error('Sending message failed:', err.message) // the in-app notification is already saved
    }
  }
}

/** Same, but at most once per calendar day (in the app time zone) per medicine and type. */
export async function notifyOncePerDay(deps, ownerId, medicineId, type, message) {
  const { rows } = await deps.pool.query(
    `select 1 from notifications
      where owner_id = $1 and medicine_id = $2 and type = $3
        and created_at >= (date_trunc('day', now() at time zone $4) at time zone $4)
      limit 1`,
    [ownerId, medicineId, type, deps.config.timezone],
  )
  if (rows.length === 0) await notifyCaregiver(deps, ownerId, medicineId, type, message)
}

/** Sends a reminder straight to the person taking the medicine (no in-app record). */
export async function remindMember({ channel }, phone, message) {
  if (!phone) return
  try {
    await channel.send(phone, message)
  } catch (err) {
    console.error('Sending reminder failed:', err.message)
  }
}
