import { addDays, zoned } from '../time.js'
import { checkMany } from '../verification.js'

// Every medicine query goes through this join, so a medicine is only ever visible to the owner
// of the family member it belongs to.
export const MEDICINE_SELECT = `
  select m.*, fm.name as member_name, fm.phone as member_phone, fm.owner_id
    from medicines m
    join family_members fm on fm.id = m.member_id`

export const doseTimeList = (m) => (m.dose_times ? m.dose_times.split(',').filter(Boolean).sort() : [])

/** Whole days of stock left at the current dosing rate. */
export const daysLeft = (m) => Math.floor(m.tablets_remaining / Math.max(1, m.doses_per_day * m.tablets_per_dose))

/** Converts database rows to the API shape, adding the live safety check. */
export async function toViews(deps, rows) {
  const checks = await checkMany(deps, rows.map((m) => ({
    batchNumber: m.batch_number, expiryDate: m.expiry_date, code: m.scan_code,
  })))
  const today = zoned(deps.config.timezone).date
  return rows.map((m, i) => {
    const left = daysLeft(m)
    return {
      id: m.id,
      memberId: m.member_id,
      memberName: m.member_name,
      name: m.name,
      strength: m.strength,
      batchNumber: m.batch_number,
      expiryDate: m.expiry_date,
      scanCode: m.scan_code,
      dosesPerDay: m.doses_per_day,
      doseTimes: doseTimeList(m),
      tabletsPerDose: m.tablets_per_dose,
      tabletsRemaining: m.tablets_remaining,
      refillLeadDays: m.refill_lead_days,
      notes: m.notes,
      active: m.active,
      daysLeft: left,
      refillDueDate: addDays(today, Math.max(0, left - m.refill_lead_days)),
      verification: checks[i],
    }
  })
}

export async function loadView(deps, medicineId, userId) {
  const { rows } = await deps.pool.query(`${MEDICINE_SELECT} where m.id = $1 and fm.owner_id = $2`, [medicineId, userId])
  return rows[0] ? (await toViews(deps, rows))[0] : null
}
