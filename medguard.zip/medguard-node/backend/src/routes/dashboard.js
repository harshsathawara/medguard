import express from 'express'
import { handler } from '../errors.js'
import { doseTimeList, daysLeft, MEDICINE_SELECT } from '../services/medicines.js'
import { addDays, localEpochMin, zoned } from '../time.js'
import { checkMany } from '../verification.js'

export default function dashboardRoutes(deps) {
  const { pool, config } = deps
  const r = express.Router()

  r.get('/', handler(async (req, res) => {
    const uid = req.userId
    const now = zoned(config.timezone)

    const [medsRes, logsRes, membersRes, unreadRes] = await Promise.all([
      pool.query(`${MEDICINE_SELECT} where fm.owner_id = $1 and m.active order by lower(m.name)`, [uid]),
      pool.query(
        `select dl.medicine_id, dl.scheduled_time, dl.status
           from dose_logs dl
           join medicines m on m.id = dl.medicine_id
           join family_members fm on fm.id = m.member_id
          where fm.owner_id = $1 and dl.scheduled_time >= $2 and dl.scheduled_time < $3`,
        [uid, `${now.date}T00:00:00`, `${addDays(now.date, 1)}T00:00:00`],
      ),
      pool.query('select count(*)::int as n from family_members where owner_id = $1', [uid]),
      pool.query('select count(*)::int as n from notifications where owner_id = $1 and not seen', [uid]),
    ])

    const meds = medsRes.rows
    const logged = new Map(logsRes.rows.map((l) => [`${l.medicine_id}@${l.scheduled_time.slice(11, 16)}`, l.status]))
    const checks = await checkMany(deps, meds.map((m) => ({ batchNumber: m.batch_number, expiryDate: m.expiry_date, code: m.scan_code })))

    const alerts = []
    const today = []

    meds.forEach((m, i) => {
      const who = m.member_name
      const v = checks[i]

      if (v.expiry === 'EXPIRED') {
        alerts.push({ level: 'DANGER', type: 'EXPIRED', medicineId: m.id, message: `${m.name} (${who}) is expired. Stop using it.` })
      } else if (v.expiry === 'EXPIRING_SOON') {
        alerts.push({ level: 'WARN', type: 'EXPIRING', medicineId: m.id, message: `${m.name} (${who}) expires in ${v.daysToExpiry} day(s).` })
      }
      if (v.batch === 'SUSPICIOUS') {
        alerts.push({ level: 'DANGER', type: 'SUSPICIOUS_BATCH', medicineId: m.id, message: `${m.name} batch ${m.batch_number} was reported as suspicious.` })
      }

      const times = doseTimeList(m)
      const left = daysLeft(m)
      if (m.tablets_remaining === 0) {
        alerts.push({ level: 'DANGER', type: 'OUT_OF_STOCK', medicineId: m.id, message: `${m.name} (${who}) has run out. Refill now.` })
      } else if (times.length && left <= m.refill_lead_days) {
        alerts.push({ level: left <= 2 ? 'DANGER' : 'WARN', type: 'REFILL', medicineId: m.id, message: `${m.name} (${who}) has about ${left} day(s) of stock left.` })
      }

      for (const t of times) {
        const slotMin = localEpochMin(now.date, t)
        let status = logged.get(`${m.id}@${t}`)
        if (!status) {
          if (now.epochMin > slotMin + config.missedAfterMinutes) status = 'MISSED'
          else if (now.epochMin > slotMin) status = 'DUE'
          else status = 'UPCOMING'
        }
        today.push({ medicineId: m.id, medicineName: m.name, memberName: who, time: t, status })
      }
    })

    alerts.sort((a, b) => (a.level === 'DANGER' ? 0 : 1) - (b.level === 'DANGER' ? 0 : 1))
    today.sort((a, b) => a.time.localeCompare(b.time) || a.medicineName.localeCompare(b.medicineName))

    res.json({
      memberCount: membersRes.rows[0].n,
      medicineCount: meds.length,
      unreadNotifications: unreadRes.rows[0].n,
      alerts,
      today,
    })
  }))

  return r
}
