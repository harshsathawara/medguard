import bcrypt from 'bcryptjs'
import express from 'express'
import { signToken } from '../auth.js'
import { AppError, handler } from '../errors.js'
import { parse, schemas } from '../validate.js'

const view = (u) => ({ id: u.id, name: u.name, email: u.email, phone: u.phone })

// Used to spend the same time on unknown emails as on wrong passwords.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10)

export default function authRoutes({ pool, config }, requireAuth) {
  const r = express.Router()

  r.post('/register', handler(async (req, res) => {
    const b = parse(schemas.register, req.body)
    const hash = await bcrypt.hash(b.password, 10)
    let user
    try {
      const { rows } = await pool.query(
        'insert into app_users (name, email, password_hash, phone) values ($1, $2, $3, $4) returning *',
        [b.name, b.email, hash, b.phone],
      )
      user = rows[0]
    } catch (err) {
      if (err.code === '23505') throw new AppError(409, 'An account with this email already exists')
      throw err
    }
    res.json({ token: signToken(config, user.id), user: view(user) })
  }))

  r.post('/login', handler(async (req, res) => {
    const b = parse(schemas.login, req.body)
    const { rows } = await pool.query('select * from app_users where lower(email) = lower($1)', [b.email.trim()])
    const user = rows[0]
    const ok = await bcrypt.compare(b.password, user ? user.password_hash : DUMMY_HASH)
    if (!user || !ok) throw new AppError(401, 'Wrong email or password')
    res.json({ token: signToken(config, user.id), user: view(user) })
  }))

  r.get('/me', requireAuth, handler(async (req, res) => {
    const { rows } = await pool.query('select * from app_users where id = $1', [req.userId])
    if (!rows[0]) throw new AppError(404, 'User not found')
    res.json(view(rows[0]))
  }))

  return r
}
