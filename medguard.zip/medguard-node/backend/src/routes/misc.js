import express from 'express'
import { AppError, handler, idParam, notFound } from '../errors.js'
import { check } from '../verification.js'
import { parse, schemas } from '../validate.js'

/** Stand-alone "check this strip before I buy / use it" endpoint. Nothing is stored. */
export function verifyRoutes(deps) {
  const r = express.Router()
  r.post('/', handler(async (req, res) => {
    const b = parse(schemas.verify, req.body)
    res.json(await check(deps, { batchNumber: b.batchNumber, expiryDate: b.expiryDate, code: b.code }))
  }))
  return r
}

const reportView = (s) => ({
  id: s.id, medicineName: s.medicine_name, batchNumber: s.batch_number, manufacturer: s.manufacturer,
  pharmacy: s.pharmacy, reason: s.reason, createdAt: s.created_at,
})

export function reportRoutes({ pool }) {
  const r = express.Router()

  r.post('/', handler(async (req, res) => {
    const b = parse(schemas.report, req.body)
    try {
      const { rows } = await pool.query(
        `insert into suspicious_reports (reporter_id, medicine_name, batch_number, manufacturer, pharmacy, reason)
         values ($1, $2, $3, $4, $5, $6) returning *`,
        [req.userId, b.medicineName, b.batchNumber, b.manufacturer, b.pharmacy, b.reason],
      )
      res.json(reportView(rows[0]))
    } catch (err) {
      if (err.code === '23505') throw new AppError(409, 'You already reported this batch')
      throw err
    }
  }))

  // Only the caller's own reports. Other users' reports surface only as counts in the verification result.
  r.get('/', handler(async (req, res) => {
    const { rows } = await pool.query('select * from suspicious_reports where reporter_id = $1 order by created_at desc', [req.userId])
    res.json(rows.map(reportView))
  }))

  return r
}

const noteView = (n) => ({
  id: n.id, medicineId: n.medicine_id, type: n.type, message: n.message, seen: n.seen, createdAt: n.created_at,
})

export function notificationRoutes({ pool }) {
  const r = express.Router()

  r.get('/', handler(async (req, res) => {
    const { rows } = await pool.query('select * from notifications where owner_id = $1 order by created_at desc, id desc limit 100', [req.userId])
    res.json(rows.map(noteView))
  }))

  // Declared before "/:id/seen" so "seen-all" is never read as an id.
  r.post('/seen-all', handler(async (req, res) => {
    await pool.query('update notifications set seen = true where owner_id = $1 and not seen', [req.userId])
    res.status(204).end()
  }))

  r.post('/:id/seen', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Notification')
    const { rowCount } = await pool.query('update notifications set seen = true where id = $1 and owner_id = $2', [id, req.userId])
    if (!rowCount) throw notFound('Notification')
    res.status(204).end()
  }))

  return r
}
