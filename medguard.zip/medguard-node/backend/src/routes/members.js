import express from 'express'
import { handler, idParam, notFound } from '../errors.js'
import { parse, schemas } from '../validate.js'

const SELECT = `
  select fm.*, (select count(*)::int from medicines m where m.member_id = fm.id) as medicine_count
    from family_members fm`

const view = (m) => ({
  id: m.id, name: m.name, relation: m.relation, phone: m.phone, language: m.language,
  medicineCount: m.medicine_count,
})

export default function memberRoutes({ pool }) {
  const r = express.Router()

  r.get('/', handler(async (req, res) => {
    const { rows } = await pool.query(`${SELECT} where fm.owner_id = $1 order by lower(fm.name)`, [req.userId])
    res.json(rows.map(view))
  }))

  r.post('/', handler(async (req, res) => {
    const b = parse(schemas.member, req.body)
    const { rows } = await pool.query(
      `insert into family_members (owner_id, name, relation, phone, language) values ($1, $2, $3, $4, $5) returning id`,
      [req.userId, b.name, b.relation, b.phone, b.language],
    )
    const created = await pool.query(`${SELECT} where fm.id = $1`, [rows[0].id])
    res.json(view(created.rows[0]))
  }))

  r.put('/:id', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Family member')
    const b = parse(schemas.member, req.body)
    const { rowCount } = await pool.query(
      `update family_members set name = $1, relation = $2, phone = $3, language = $4
        where id = $5 and owner_id = $6`,
      [b.name, b.relation, b.phone, b.language, id, req.userId],
    )
    if (!rowCount) throw notFound('Family member')
    const updated = await pool.query(`${SELECT} where fm.id = $1`, [id])
    res.json(view(updated.rows[0]))
  }))

  // Their medicines and dose logs are removed by "on delete cascade".
  r.delete('/:id', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Family member')
    const { rowCount } = await pool.query('delete from family_members where id = $1 and owner_id = $2', [id, req.userId])
    if (!rowCount) throw notFound('Family member')
    res.status(204).end()
  }))

  return r
}
