import express from 'express'
import { tx } from '../db.js'
import { AppError, handler, idParam, notFound } from '../errors.js'
import { doseTimeList, loadView, MEDICINE_SELECT, toViews } from '../services/medicines.js'
import { zoned } from '../time.js'
import { parse, schemas } from '../validate.js'

/** Turns a validated request body into column values. `existing` is the current row when updating. */
function fields(b, existing) {
  const times = b.doseTimes == null
    ? (existing ? doseTimeList(existing) : [])
    : [...new Set(b.doseTimes)].sort()
  return [
    b.name, b.strength, b.batchNumber, b.expiryDate, b.scanCode,
    times.length || b.dosesPerDay || existing?.doses_per_day || 1,
    times.join(','),
    b.tabletsPerDose ?? existing?.tablets_per_dose ?? 1,
    b.tabletsRemaining ?? existing?.tablets_remaining ?? 0,
    b.refillLeadDays ?? existing?.refill_lead_days ?? 7,
    b.notes,
    b.active ?? existing?.active ?? true,
  ]
}

const doseView = (l) => ({ id: l.id, status: l.status, scheduledTime: l.scheduled_time, loggedAt: l.logged_at })

export default function medicineRoutes(deps) {
  const { pool, config } = deps
  const r = express.Router()

  const owned = async (id, userId) => {
    const { rows } = await pool.query(`${MEDICINE_SELECT} where m.id = $1 and fm.owner_id = $2`, [id, userId])
    if (!rows[0]) throw notFound('Medicine')
    return rows[0]
  }

  const ownedMember = async (memberId, userId) => {
    const { rows } = await pool.query('select id from family_members where id = $1 and owner_id = $2', [memberId, userId])
    if (!rows[0]) throw notFound('Family member')
  }

  r.get('/', handler(async (req, res) => {
    const params = [req.userId]
    let where = 'fm.owner_id = $1'
    if (req.query.memberId !== undefined) {
      params.push(idParam(req.query.memberId, 'Family member'))
      where += ' and m.member_id = $2'
    }
    const { rows } = await pool.query(`${MEDICINE_SELECT} where ${where} order by lower(m.name)`, params)
    res.json(await toViews(deps, rows))
  }))

  r.get('/:id', handler(async (req, res) => {
    const view = await loadView(deps, idParam(req.params.id, 'Medicine'), req.userId)
    if (!view) throw notFound('Medicine')
    res.json(view)
  }))

  r.post('/', handler(async (req, res) => {
    const b = parse(schemas.medicine, req.body)
    await ownedMember(b.memberId, req.userId)
    const { rows } = await pool.query(
      `insert into medicines (member_id, name, strength, batch_number, expiry_date, scan_code, doses_per_day,
                              dose_times, tablets_per_dose, tablets_remaining, refill_lead_days, notes, active)
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) returning id`,
      [b.memberId, ...fields(b, null)],
    )
    res.json(await loadView(deps, rows[0].id, req.userId))
  }))

  r.put('/:id', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Medicine')
    const b = parse(schemas.medicine, req.body)
    const existing = await owned(id, req.userId)
    await ownedMember(b.memberId, req.userId)
    await pool.query(
      `update medicines set member_id = $1, name = $2, strength = $3, batch_number = $4, expiry_date = $5,
              scan_code = $6, doses_per_day = $7, dose_times = $8, tablets_per_dose = $9,
              tablets_remaining = $10, refill_lead_days = $11, notes = $12, active = $13
        where id = $14`,
      [b.memberId, ...fields(b, existing), id],
    )
    res.json(await loadView(deps, id, req.userId))
  }))

  r.delete('/:id', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Medicine')
    await owned(id, req.userId)
    await pool.query('delete from medicines where id = $1', [id]) // dose logs cascade
    res.status(204).end()
  }))

  r.post('/:id/refill', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Medicine')
    const b = parse(schemas.refill, req.body)
    await owned(id, req.userId)
    await pool.query('update medicines set tablets_remaining = tablets_remaining + $1 where id = $2', [b.quantity, id])
    res.json(await loadView(deps, id, req.userId))
  }))

  /**
   * Records a dose. With `time` (HH:mm) the log answers that slot of today; a slot that was
   * auto-marked MISSED can still be corrected. Taking a dose reduces the stock.
   */
  r.post('/:id/doses', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Medicine')
    const b = parse(schemas.dose, req.body)
    const slot = b.time ? `${zoned(config.timezone).date}T${b.time}:00` : null

    const log = await tx(pool, async (c) => {
      const med = await c.query(
        `select m.id, m.tablets_per_dose from medicines m join family_members fm on fm.id = m.member_id
          where m.id = $1 and fm.owner_id = $2 for update of m`,
        [id, req.userId],
      )
      if (!med.rows[0]) throw notFound('Medicine')

      let saved
      if (slot) {
        const ex = await c.query('select * from dose_logs where medicine_id = $1 and scheduled_time = $2 for update', [id, slot])
        if (ex.rows[0]) {
          if (ex.rows[0].status !== 'MISSED') throw new AppError(409, 'This dose is already logged')
          saved = (await c.query('update dose_logs set status = $1, logged_at = now() where id = $2 returning *', [b.status, ex.rows[0].id])).rows[0]
        }
      }
      if (!saved) {
        saved = (await c.query(
          'insert into dose_logs (medicine_id, scheduled_time, status) values ($1, $2, $3) returning *',
          [id, slot, b.status],
        )).rows[0]
      }
      if (b.status === 'TAKEN') {
        await c.query(
          'update medicines set tablets_remaining = greatest(0, tablets_remaining - $1) where id = $2',
          [med.rows[0].tablets_per_dose, id],
        )
      }
      return saved
    })
    res.json(doseView(log))
  }))

  r.get('/:id/doses', handler(async (req, res) => {
    const id = idParam(req.params.id, 'Medicine')
    await owned(id, req.userId)
    const { rows } = await pool.query('select * from dose_logs where medicine_id = $1 order by logged_at desc limit 50', [id])
    res.json(rows.map(doseView))
  }))

  return r
}
