import { daysBetween, zoned } from './time.js'

const EXPIRING_SOON_DAYS = 60

/**
 * Pure verdict logic (no I/O).
 * ctx: { today, reportCount, authenticity, threshold }
 */
export function evaluate({ batchNumber, expiryDate }, ctx) {
  const messages = []

  // 1. Expiry
  let expiry = 'UNKNOWN'
  let daysToExpiry = null
  if (expiryDate) {
    daysToExpiry = daysBetween(ctx.today, expiryDate)
    if (daysToExpiry < 0) {
      expiry = 'EXPIRED'
      messages.push(`Expired ${Math.abs(daysToExpiry)} day(s) ago. Do not use it.`)
    } else if (daysToExpiry <= EXPIRING_SOON_DAYS) {
      expiry = 'EXPIRING_SOON'
      messages.push(`Expires in ${daysToExpiry} day(s). Use it up or replace it soon.`)
    } else {
      expiry = 'OK'
    }
  } else {
    messages.push('No expiry date entered, so expiry could not be checked.')
  }

  // 2. Community reports for this batch
  let batch = 'NOT_CHECKED'
  const reportCount = ctx.reportCount || 0
  if (batchNumber) {
    if (reportCount >= ctx.threshold) {
      batch = 'SUSPICIOUS'
      messages.push(`Batch ${batchNumber} was reported as suspicious by ${reportCount} different users. Take it back to the pharmacy.`)
    } else if (reportCount > 0) {
      batch = 'REPORTED'
      messages.push(`Batch ${batchNumber} has ${reportCount} report(s) from users. Check the pack carefully.`)
    } else {
      batch = 'CLEAN'
    }
  } else {
    messages.push('No batch number entered, so community reports could not be checked.')
  }

  // 3. Authenticity registry (pluggable, see extensions.js)
  const authenticity = ctx.authenticity
  if (authenticity === 'VERIFIED') messages.push('The batch code was confirmed by the registry.')
  else if (authenticity === 'NOT_FOUND') messages.push('The code was NOT found in the registry. It may be fake.')
  else messages.push('Authenticity could not be verified against an official registry. This check only covers expiry and community reports.')

  let verdict
  if (expiry === 'EXPIRED' || batch === 'SUSPICIOUS' || authenticity === 'NOT_FOUND') verdict = 'DANGER'
  else if (expiry === 'EXPIRING_SOON' || expiry === 'UNKNOWN' || batch === 'REPORTED' || batch === 'NOT_CHECKED') verdict = 'CAUTION'
  else verdict = 'SAFE'

  return { verdict, expiry, daysToExpiry, batch, reportCount, authenticity, messages }
}

/** Distinct reporters per batch (case-insensitive), so one person cannot flag a batch alone. */
async function reportCounts(pool, batches) {
  const unique = [...new Set(batches.filter(Boolean).map((b) => b.trim().toLowerCase()))]
  const counts = new Map()
  if (unique.length === 0) return counts
  const { rows } = await pool.query(
    `select lower(batch_number) as batch, count(distinct reporter_id)::int as n
       from suspicious_reports
      where lower(batch_number) = any($1)
      group by 1`,
    [unique],
  )
  for (const r of rows) counts.set(r.batch, r.n)
  return counts
}

/** Checks many strips with one report query. inputs: [{ batchNumber, expiryDate, code }] */
export async function checkMany({ pool, config, registry }, inputs) {
  const today = zoned(config.timezone).date
  const counts = await reportCounts(pool, inputs.map((i) => i.batchNumber))
  return Promise.all(inputs.map(async (input) => {
    let authenticity = 'UNAVAILABLE'
    try {
      authenticity = await registry.lookup({ code: input.code, batchNumber: input.batchNumber })
    } catch (err) {
      console.error('Registry lookup failed:', err.message) // an outage must not break the app
    }
    return evaluate(input, {
      today,
      authenticity,
      threshold: config.suspiciousThreshold,
      reportCount: input.batchNumber ? counts.get(input.batchNumber.trim().toLowerCase()) || 0 : 0,
    })
  }))
}

export async function check(deps, input) {
  return (await checkMany(deps, [input]))[0]
}
