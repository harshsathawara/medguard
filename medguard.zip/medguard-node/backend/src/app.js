import cors from 'cors'
import express from 'express'
import { rateLimit } from 'express-rate-limit'
import helmet from 'helmet'
import { requireAuth } from './auth.js'
import { errorMiddleware } from './errors.js'
import authRoutes from './routes/auth.js'
import dashboardRoutes from './routes/dashboard.js'
import medicineRoutes from './routes/medicines.js'
import memberRoutes from './routes/members.js'
import { notificationRoutes, reportRoutes, verifyRoutes } from './routes/misc.js'

/** deps: { pool, config, channel, registry } */
export function createApp(deps) {
  const { pool, config } = deps
  const app = express()

  app.set('trust proxy', config.trustProxy)
  app.disable('x-powered-by')
  app.use(helmet())
  app.use(cors({ origin: config.corsOrigins }))
  app.use(express.json({ limit: '100kb' }))

  // Public
  app.get('/api/health', async (req, res) => {
    try {
      await pool.query('select 1')
      res.json({ status: 'ok' })
    } catch {
      res.status(503).json({ status: 'database unavailable' })
    }
  })

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: config.authRateLimit,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many attempts. Please wait a few minutes and try again.' },
  })
  const needAuth = requireAuth(config)
  // The limiter applies to login and register only, not to GET /api/auth/me.
  app.use('/api/auth/login', authLimiter)
  app.use('/api/auth/register', authLimiter)
  app.use('/api/auth', authRoutes(deps, needAuth))

  // Everything below needs a valid token
  app.use('/api/members', needAuth, memberRoutes(deps))
  app.use('/api/medicines', needAuth, medicineRoutes(deps))
  app.use('/api/verify', needAuth, verifyRoutes(deps))
  app.use('/api/reports', needAuth, reportRoutes(deps))
  app.use('/api/notifications', needAuth, notificationRoutes(deps))
  app.use('/api/dashboard', needAuth, dashboardRoutes(deps))

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }))
  app.use(errorMiddleware)
  return app
}
