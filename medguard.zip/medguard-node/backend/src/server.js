import { createApp } from './app.js'
import { loadConfig } from './config.js'
import { createPool, migrate } from './db.js'
import { createChannel, createRegistry } from './extensions.js'
import { startScheduler } from './scheduler.js'

const config = loadConfig()
const pool = createPool(config.db)

try {
  await migrate(pool)
} catch (err) {
  console.error(`Could not prepare the database (${err.message}). Is PostgreSQL running and are the DATABASE_URL / DB_* settings correct?`)
  process.exit(1)
}

const deps = { pool, config, channel: createChannel(), registry: createRegistry() }
const server = createApp(deps).listen(config.port, () => {
  console.log(`MedGuard API listening on http://localhost:${config.port} (time zone ${config.timezone})`)
})

const stopScheduler = config.schedulerEnabled ? startScheduler(deps) : () => {}

async function shutdown(signal) {
  console.log(`${signal} received, shutting down`)
  stopScheduler()
  server.close(async () => {
    await pool.end().catch(() => {})
    process.exit(0)
  })
  setTimeout(() => process.exit(1), 10_000).unref()
}
process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
