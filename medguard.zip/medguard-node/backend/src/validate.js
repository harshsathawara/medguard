import { z } from 'zod'
import { AppError } from './errors.js'

const optText = (max = 200) =>
  z.string().trim().max(max).nullish().transform((v) => (v ? v : null))

const isRealDate = (s) => {
  const d = new Date(`${s}T00:00:00Z`)
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s
}

const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'must be YYYY-MM-DD').refine(isRealDate, 'is not a real date')
const optDate = z.union([dateStr, z.literal(''), z.null()]).optional().transform((v) => v || null)
const hhmm = z.string().trim().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'must be HH:mm, for example 08:00')

export const schemas = {
  register: z.object({
    name: z.string().trim().min(1, 'is required').max(100),
    email: z.string().trim().toLowerCase().email('must be a valid email').max(200),
    password: z.string().min(8, 'must be at least 8 characters').max(200),
    phone: optText(30),
  }),
  login: z.object({
    email: z.string().trim().min(1, 'is required'),
    password: z.string().min(1, 'is required'),
  }),
  member: z.object({
    name: z.string().trim().min(1, 'is required').max(100),
    relation: optText(50),
    phone: optText(30),
    language: optText(50),
  }),
  medicine: z.object({
    memberId: z.number().int().positive(),
    name: z.string().trim().min(1, 'is required').max(200),
    strength: optText(50),
    batchNumber: optText(100),
    expiryDate: optDate,
    scanCode: optText(1000),
    dosesPerDay: z.number().int().min(1).max(12).nullish(),
    doseTimes: z.array(hhmm).max(12).nullish(),
    tabletsPerDose: z.number().int().min(1).max(20).nullish(),
    tabletsRemaining: z.number().int().min(0).max(100000).nullish(),
    refillLeadDays: z.number().int().min(0).max(60).nullish(),
    notes: optText(1000),
    active: z.boolean().nullish(),
  }),
  refill: z.object({ quantity: z.number().int().min(1).max(100000) }),
  dose: z.object({
    status: z.enum(['TAKEN', 'SKIPPED', 'MISSED']),
    time: hhmm.nullish().or(z.literal('')),
  }),
  verify: z.object({
    medicineName: optText(200),
    batchNumber: optText(100),
    expiryDate: optDate,
    code: optText(1000),
  }),
  report: z.object({
    medicineName: z.string().trim().min(1, 'is required').max(200),
    batchNumber: z.string().trim().min(1, 'is required').max(100),
    manufacturer: optText(200),
    pharmacy: optText(200),
    reason: optText(2000),
  }),
}

/** Validates a request body, answering 400 with a readable message. */
export function parse(schema, body) {
  const result = schema.safeParse(body ?? {})
  if (result.success) return result.data
  const msg = result.error.issues
    .map((i) => `${i.path.join('.') || 'body'} ${i.message}`)
    .join('; ')
  throw new AppError(400, msg)
}
