import jwt from 'jsonwebtoken'

export function signToken(config, userId) {
  return jwt.sign({}, config.jwtSecret, {
    algorithm: 'HS256',
    subject: String(userId),
    expiresIn: config.jwtExpiry,
  })
}

/** Express middleware: requires "Authorization: Bearer <token>" and sets req.userId. */
export function requireAuth(config) {
  return (req, res, next) => {
    const header = req.headers.authorization || ''
    if (header.startsWith('Bearer ')) {
      try {
        const payload = jwt.verify(header.slice(7), config.jwtSecret, { algorithms: ['HS256'] })
        req.userId = Number(payload.sub)
        return next()
      } catch {
        /* invalid or expired: fall through to 401 */
      }
    }
    res.status(401).json({ error: 'Unauthorized' })
  }
}
