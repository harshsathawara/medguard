import { daysBetween, addDays, localEpochMin, zoned } from './time.js'
import { daysLeft, doseTimeList, MEDICINE_SELECT } from './services/medicines.js'
import { notifyCaregiver, notifyOncePerDay, remindMember } from './services/notifications.js'

// A missed dose is only reported while it is this fresh (minutes after the "missed" cut-off).
// This stops a restart after downtime from flooding caregivers with stale alerts.
const MISSED_REPORT_WINDOW = 180

/**
 * Runs once per minute.
 *  - At a dose time, reminds the person (if they have a phone number).
 *  - `missedAfterMinutes` later, if nobody answered, marks the dose MISSED and alerts the caregiver.
 * `now` can be passed in (used by the tests).
 */
export async function everyMinute(deps, now = zoned(deps.config.timezone)) {
  const { pool, config } = deps
  const { rows: meds } = await pool.query(`${MEDICINE_SELECT} where m.active`)

  for (const m of meds) {
    const createdMin = zoned(config.timezone, m.created_at).epochMin
    for (const t of doseTimeList(m)) {
      // yesterday matters only for doses late at night whose "missed" time falls after midnight
      for (const date of [addDays(now.date, -1), now.date]) {
        const slotMin = localEpochMin(date, t)

        if (date === now.date && t === now.time) {
          await remindMember(deps, m.member_phone,
            `Time for your medicine: ${m.name}${m.strength ? ` ${m.strength}` : ''} (${m.tablets_per_dose} tablet(s)).`)
        }

        const age = now.epochMin - slotMin
        const overdue = age >= config.missedAfterMinutes && age < config.missedAfterMinutes + MISSED_REPORT_WINDOW
        // Doses that were due before the medicine was added are not "missed".
        if (overdue && slotMin >= createdMin) {
          const { rows } = await pool.query(
            `insert into dose_logs (medicine_id, scheduled_time, status) values ($1, $2, 'MISSED')
             on conflict (medicine_id, scheduled_time) do nothing returning id`,
            [m.id, `${date}T${t}:00`],
          )
          if (rows.length) {
            await notifyCaregiver(deps, m.owner_id, m.id, 'DOSE_MISSED', `${m.member_name} has not taken ${m.name} (${t}).`)
          }
        }
      }
    }
  }
}

/** Refill and expiry alerts, at most one per medicine per type per day. */
export async function dailyChecks(deps, now = zoned(deps.config.timezone)) {
  const { rows: meds } = await deps.pool.query(`${MEDICINE_SELECT} where m.active`)

  for (const m of meds) {
    const who = m.member_name
    const left = daysLeft(m)

    if (m.tablets_remaining === 0) {
      await notifyOncePerDay(deps, m.owner_id, m.id, 'REFILL', `${m.name} for ${who} has run out.`)
    } else if (doseTimeList(m).length && left <= m.refill_lead_days) {
      await notifyOncePerDay(deps, m.owner_id, m.id, 'REFILL', `${m.name} for ${who} will run out in about ${left} day(s). Time to reorder.`)
    }

    if (m.expiry_date) {
      const days = daysBetween(now.date, m.expiry_date)
      if (days < 0) {
        await notifyOncePerDay(deps, m.owner_id, m.id, 'EXPIRY', `${m.name} for ${who} is expired. Stop using it.`)
      } else if (days <= 30) {
        await notifyOncePerDay(deps, m.owner_id, m.id, 'EXPIRY', `${m.name} for ${who} expires in ${days} day(s).`)
      }
    }
  }
}

/** Starts the background jobs. Returns a function that stops them. */
export function startScheduler(deps) {
  let lastMinute = ''
  let running = false

  const tick = async () => {
    if (running) return // the previous run is still busy
    const now = zoned(deps.config.timezone)
    const minute = now.dateTime.slice(0, 16)
    if (minute === lastMinute) return
    lastMinute = minute
    running = true
    try {
      await everyMinute(deps, now)
      if (now.time === '09:00') await dailyChecks(deps, now)
    } catch (err) {
      console.error('Scheduler error:', err.message)
    } finally {
      running = false
    }
  }

  // Also run the daily checks at startup; they are de-duplicated per day, so this is safe.
  dailyChecks(deps).catch((err) => console.error('Daily check error:', err.message))

  const timer = setInterval(tick, 10_000)
  timer.unref?.()
  return () => clearInterval(timer)
}
