export class AppError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

export const notFound = (what) => new AppError(404, `${what} not found`)

/** Lets route handlers be async functions without try/catch. */
export const handler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next)

/** Parses an :id route parameter, answering 404 for anything that is not a positive integer. */
export function idParam(value, what = 'Item') {
  const n = Number(value)
  if (!Number.isInteger(n) || n < 1 || n > 2147483647) throw notFound(what)
  return n
}

// Every error leaves the API as {"error": "..."}.
// eslint-disable-next-line no-unused-vars
export function errorMiddleware(err, req, res, next) {
  if (err instanceof AppError) return res.status(err.status).json({ error: err.message })
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Request body is not valid JSON' })
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body is too large' })
  if (err.code === '23505') return res.status(409).json({ error: 'That already exists' }) // unique violation
  console.error('Unhandled error:', err)
  res.status(500).json({ error: 'Something went wrong' })
}
