// Time helpers. Dose times are "wall clock" times in the app's time zone (APP_TIMEZONE), so all
// day/time maths here is done on plain local date strings instead of JS Dates in the server's zone.

const formatters = new Map()

function formatter(tz) {
  if (!formatters.has(tz)) {
    formatters.set(tz, new Intl.DateTimeFormat('en-CA', {
      timeZone: tz, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    }))
  }
  return formatters.get(tz)
}

/** The given instant (default: now) as local parts in `tz`. */
export function zoned(tz, instant = new Date()) {
  const p = {}
  for (const part of formatter(tz).formatToParts(instant)) {
    if (part.type !== 'literal') p[part.type] = part.value
  }
  const date = `${p.year}-${p.month}-${p.day}`
  const time = `${p.hour}:${p.minute}`
  return {
    date,                                   // "2026-10-28"
    time,                                   // "17:05"
    dateTime: `${date}T${time}:${p.second}`, // "2026-10-28T17:05:09"
    epochMin: localEpochMin(date, time),    // minutes since 1970 on the local clock, for differences
  }
}

export function localEpochMin(date, hhmm) {
  const [y, m, d] = date.split('-').map(Number)
  const [h, mi] = hhmm.split(':').map(Number)
  return Date.UTC(y, m - 1, d, h, mi) / 60000
}

export function addDays(date, n) {
  const [y, m, d] = date.split('-').map(Number)
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10)
}

/** Whole days from `from` to `to` (both "YYYY-MM-DD"); negative when `to` is earlier. */
export function daysBetween(from, to) {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000)
}
