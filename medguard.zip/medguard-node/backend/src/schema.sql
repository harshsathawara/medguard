-- MedGuard schema. Idempotent: safe to run on every start.
-- For bigger teams, move to a migration tool (node-pg-migrate, Knex, Prisma Migrate) when the schema starts changing.

create table if not exists app_users (
  id            serial primary key,
  name          text        not null,
  email         text        not null,
  password_hash text        not null,
  phone         text,
  created_at    timestamptz not null default now()
);
create unique index if not exists app_users_email_lower_idx on app_users (lower(email));

create table if not exists family_members (
  id         serial primary key,
  owner_id   integer     not null references app_users (id) on delete cascade,
  name       text        not null,
  relation   text,
  phone      text,
  language   text,
  created_at timestamptz not null default now()
);
create index if not exists family_members_owner_idx on family_members (owner_id);

create table if not exists medicines (
  id                serial primary key,
  member_id         integer     not null references family_members (id) on delete cascade,
  name              text        not null,
  strength          text,
  batch_number      text,
  expiry_date       date,
  scan_code         text,
  doses_per_day     integer     not null default 1 check (doses_per_day between 1 and 12),
  dose_times        text        not null default '',          -- "08:00,20:00"
  tablets_per_dose  integer     not null default 1 check (tablets_per_dose between 1 and 20),
  tablets_remaining integer     not null default 0 check (tablets_remaining >= 0),
  refill_lead_days  integer     not null default 7 check (refill_lead_days between 0 and 60),
  notes             text,
  active            boolean     not null default true,
  created_at        timestamptz not null default now()
);
create index if not exists medicines_member_idx on medicines (member_id);

create table if not exists dose_logs (
  id             serial primary key,
  medicine_id    integer     not null references medicines (id) on delete cascade,
  scheduled_time timestamp,                                    -- local (app time zone) slot; null for an ad-hoc dose
  status         text        not null check (status in ('TAKEN', 'SKIPPED', 'MISSED')),
  logged_at      timestamptz not null default now(),
  unique (medicine_id, scheduled_time)                         -- one log per slot (nulls are allowed many times)
);

create table if not exists suspicious_reports (
  id            serial primary key,
  reporter_id   integer     not null references app_users (id) on delete cascade,
  medicine_name text        not null,
  batch_number  text        not null,
  manufacturer  text,
  pharmacy      text,
  reason        text,
  created_at    timestamptz not null default now()
);
create index if not exists suspicious_reports_batch_idx on suspicious_reports (lower(batch_number));
create unique index if not exists suspicious_reports_one_per_user_idx on suspicious_reports (reporter_id, lower(batch_number));

create table if not exists notifications (
  id          serial primary key,
  owner_id    integer     not null references app_users (id) on delete cascade,
  medicine_id integer,
  type        text        not null,                            -- DOSE_MISSED, REFILL, EXPIRY
  message     text        not null,
  seen        boolean     not null default false,
  created_at  timestamptz not null default now()
);
create index if not exists notifications_owner_idx on notifications (owner_id, created_at desc);
