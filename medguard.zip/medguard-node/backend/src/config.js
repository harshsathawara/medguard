const DEV_SECRET = 'dev-only-secret-change-me-please-0123456789'

/** Reads settings from environment variables. `overrides` is used by the tests. */
export function loadConfig(overrides = {}) {
  const env = process.env
  const isProd = env.NODE_ENV === 'production'

  const config = {
    port: Number(env.PORT || 8080),
    // Either one DATABASE_URL, or separate DB_* settings (easier when the password has special characters).
    db: env.DATABASE_URL
      ? { connectionString: env.DATABASE_URL }
      : {
          host: env.DB_HOST || 'localhost',
          port: Number(env.DB_PORT || 5432),
          database: env.DB_NAME || 'medguard',
          user: env.DB_USER || 'medguard',
          password: env.DB_PASSWORD || 'medguard',
        },
    // Required in production. A fixed dev value is used otherwise so `npm start` works out of the box.
    jwtSecret: env.JWT_SECRET || (isProd ? '' : DEV_SECRET),
    jwtExpiry: env.JWT_EXPIRY || '7d',
    corsOrigins: (env.CORS_ORIGINS || 'http://localhost:5173,http://localhost:3000')
      .split(',').map((s) => s.trim()).filter(Boolean),
    // Time zone for dose times such as "08:00" and for the daily 09:00 job.
    timezone: env.APP_TIMEZONE || 'Asia/Kolkata',
    // Distinct users who must report a batch before it is flagged SUSPICIOUS.
    suspiciousThreshold: Number(env.SUSPICIOUS_THRESHOLD || 3),
    // A dose is auto-marked MISSED this many minutes after its scheduled time.
    missedAfterMinutes: Number(env.MISSED_AFTER_MINUTES || 60),
    schedulerEnabled: env.SCHEDULER_ENABLED !== 'false',
    // Max login/register attempts per IP per 15 minutes.
    authRateLimit: Number(env.AUTH_RATE_LIMIT || 30),
    // Set to 1 when running behind nginx or another reverse proxy.
    trustProxy: Number(env.TRUST_PROXY || 0),
    ...overrides,
  }

  if (!config.jwtSecret || config.jwtSecret.length < 32) {
    throw new Error('JWT_SECRET must be set and be at least 32 characters long')
  }
  try {
    new Intl.DateTimeFormat('en', { timeZone: config.timezone })
  } catch {
    throw new Error(`APP_TIMEZONE "${config.timezone}" is not a valid IANA time zone (for example Asia/Kolkata)`)
  }
  return config
}
